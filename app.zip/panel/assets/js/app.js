(() => {
    var e,
        t = {
            521: (e, t, n) => {
                "use strict";
                var a = n(455),
                    o = n.n(a),
                    s = n(640),
                    r = n.n(s);
                var i = function (e, t) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 5e3;
                        o()
                            .mixin({
                                toast: !0,
                                position: "top-start",
                                showConfirmButton: !1,
                                timer: n,
                                timerProgressBar: !0,
                                showCloseButton: !0,
                                didOpen: function (e) {
                                    e.addEventListener("mouseenter", o().stopTimer), e.addEventListener("mouseleave", o().resumeTimer);
                                },
                            })
                            .fire({ icon: e, html: t });
                    },
                    l = function (e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                        r()(e), i("success", "متن با موفقیت کپی شد", 1500), "function" == typeof t && t();
                    },
                    c = function (e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "icon";
                        return '<i class="fa fa-'.concat(e, " ").concat(t, '"></i>');
                    },
                    d = function () {
                        for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 8, t = "abcdefghijklmnopqrstuvwxyz123456789", n = "", a = 0; a < e; a++) {
                            n += t[Math.floor(35 * Math.random())];
                        }
                        return n;
                    },
                    u = function () {
                        $("#ajax-modal-view").modal("hide"), $("#ajax-modal-view").html("");
                    };
                function p(e) {
                    return (
                        (p =
                            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                                ? function (e) {
                                      return typeof e;
                                  }
                                : function (e) {
                                      return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                                  }),
                        p(e)
                    );
                }
                $(function () {
                    m(),
                        "function" == typeof $.validator &&
                            (jQuery.validator.addMethod("irMobile", function (e, t) {
                                return this.optional(t) || /^(\+98|0)?9\d{9}$/.test(e);
                            }),
                            jQuery.validator.addMethod("irTel", function (e, t) {
                                return this.optional(t) || /^(0){1}[1-9]{1}\d{5,9}$/.test(e);
                            }),
                            jQuery.validator.addMethod("enName", function (e, t) {
                                return this.optional(t) || /^[a-zA-Z]/.test(e);
                            }),
                            jQuery.validator.addMethod("username", function (e, t) {
                                return this.optional(t) || /^[a-zA-Z1-9]/.test(e);
                            }),
                            jQuery.validator.addMethod("password", function (e, t) {
                                return this.optional(t) || /^[a-zA-Z1-9]/.test(e);
                            }),
                            jQuery.validator.addMethod("faName", function (e, t) {
                                return this.optional(t) || /[^A-Za-z0-9\/s]/.test(e);
                            }),
                            jQuery.validator.addMethod("prefixUname", function (e, t) {
                                return this.optional(t) || /^[A-Za-z][A-Za-z0-9-_]*$/.test(e);
                            }),
                            jQuery.validator.addMethod("checkPassword", function (e, t) {
                                if (e.length > 0) {
                                    if (e.length >= 8) {
                                        if (/[a-zA-Z]/.test(e)) {
                                            return /[0-9]/.test(e);
                                        }
                                    }
                                    return !1;
                                }
                                return !0;
                            }),
                            jQuery.extend(jQuery.validator.messages, {
                                required: "وارد کردن فیلد الزامی است",
                                remote: "لطفا این فیلد را اصلاح کنید",
                                email: "لطفا یک آدرس ایمیل معتبر وارد کنید.",
                                url: "لطفا یک نشانی معتبر وارد کنید",
                                date: "لطفا یک تاریخ معتبر وارد کنید.",
                                dateISO: "لطفا یک تاریخ معتبر (ISO) را وارد کنید.",
                                number: "لطفا یک شماره معتبر وارد کنید.",
                                digits: "لطفا فقط رقم را وارد کنید",
                                equalTo: "لطفا مجددا همان مقدار را وارد کنید.",
                                accept: "لطفا یک مقدار با یک پسوند معتبر وارد کنید",
                                maxlength: jQuery.validator.format("لطفا حداکثر {0} نویسه را وارد کنید"),
                                minlength: jQuery.validator.format("لطفا حداقل {0} نویسه را وارد کنید"),
                                rangelength: jQuery.validator.format("لطفا یک مقدار بین {0} و {1} حرف طولانی وارد کنید"),
                                range: jQuery.validator.format("لطفا یک مقدار بین {0} و {1} را وارد کنید."),
                                max: jQuery.validator.format("لطفا یک مقدار کمتر یا برابر {0} را وارد کنید."),
                                min: jQuery.validator.format("لطفا یک مقدار بزرگتر یا برابر {0} را وارد کنید."),
                                irMobile: "شماره تلفن همراه را به صورت صحیح وارد کنید",
                                irTel: "شماره تلفن ثابت را به صورت صحیح وارد کنید",
                                minPrice: jQuery.validator.format("لطفا یک مقدار بزرگتر یا برابر {0} را وارد کنید."),
                                maxPrice: jQuery.validator.format("لطفا یک مقدار کمتر یا برابر {0} را وارد کنید."),
                                checkPassword: "رمز عبور باید شامل اعداد و حروف و حداقل 8 کاراکتر باشد",
                                enName: "فقط شامل کاراکتر های انگلیسی باشد",
                                username: "فقط شامل کاراکتر های انگلیسی و عدد باشد",
                                faName: "فقط شامل کاراکتر های فارسی باشد",
                                prefixUname: "لطفا از یک پیشوند صحیح استفاده کنید",
                            }),
                            jQuery.validator.setDefaults({
                                highlight: function (e, t, n) {
                                    $(e).parents(".form-group").addClass("has-error");
                                },
                                unhighlight: function (e, t, n) {
                                    $(e).parents(".form-group").removeClass("has-error");
                                },
                                errorPlacement: function (e, t) {
                                    var n = t.parent();
                                    t.hasClass("select2-hidden-accessible")
                                        ? e.insertAfter(t.next(".select2-container"))
                                        : n.hasClass("input-group")
                                        ? e.insertAfter(n)
                                        : t.parents(".form-control").length
                                        ? e.insertAfter(t.parents(".form-control"))
                                        : e.insertAfter(t);
                                },
                            })),
                        "function" == typeof $.fn.dataTable &&
                            ($.extend($.fn.dataTableExt.oStdClasses, { sFilterInput: "form-control", sLengthSelect: "form-select" }), $.extend($.fn.dataTable.defaults, { language: { url: assets("vendor/datatable/fa.json") } })),
                        ($.fn.loadingBtn = function (e) {
                            var t = this;
                            t.length && (e ? (t.addClass("btn-loading"), t.attr("disabled", "disabled")) : (t.removeAttr("disabled"), t.removeClass("btn-loading")));
                        }),
                        ($.ajaxRequest = function (e) {
                            var t = {
                                beforeSend: function (e) {},
                                successSend: function (e) {},
                                errorSend: function (e) {},
                                type: "post",
                                dataType: "json",
                                url: "",
                                data: {},
                                async: !0,
                                cache: !1,
                                showNotify: !0,
                                processData: !0,
                                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                            };
                            e = $.extend(t, e);
                            $.ajax({
                                type: e.type,
                                url: e.url,
                                dataType: e.dataType,
                                data: e.data,
                                async: e.async,
                                cache: e.cache,
                                processData: e.processData,
                                contentType: e.contentType,
                                beforeSend: function (e) {
                                    t.beforeSend(e);
                                },
                                success: function (e) {
                                    t.successSend(e);
                                },
                                error: function (e) {
                                    var n = e.status,
                                        a = e.responseJSON,
                                        o = e.statusText;
                                    if (200 === n) t.successSend(e);
                                    else {
                                        404 == n && (o = "صفحه مورد نظر یافت نشد");
                                        var s = o;
                                        if ("object" == p(a)) {
                                            var r = a.messages;
                                            "object" == p(r)
                                                ? ((s = ""),
                                                  Array.isArray(r)
                                                      ? r.map(function (e) {
                                                            s += "<small>".concat(e, "</small><br/>");
                                                        })
                                                      : Object.keys(r).map(function (e) {
                                                            s += "<small>".concat(r[e], "</small><br/>");
                                                        }))
                                                : (s = r),
                                                (e.messages = r);
                                        }
                                        (e.error_fields = a ? a.error_fields : null), t.errorSend(e), t.showNotify && i("error", s);
                                    }
                                },
                            });
                        }),
                        ($.fn.formSubmit = function (e) {
                            var t = {
                                    buttonLoader: !0,
                                    successSubmit: function (e) {},
                                    errorSubmit: function (e) {},
                                    beforeSubmit: function (e) {},
                                    showNotify: !0,
                                    validator: e.validator,
                                    processData: !1,
                                    submitBtn: null,
                                    contentType: "application/x-www-form-urlencoded",
                                },
                                n = this,
                                a = e.formData || n.serialize(),
                                o = ((e = $.extend(t, e)), n.find("button[type=submit]"));
                            e.submitBtn && (o = e.submitBtn),
                                $.ajaxRequest({
                                    url: n.attr("action"),
                                    data: a,
                                    type: n.attr("method"),
                                    showNotify: e.showNotify,
                                    contentType: e.contentType,
                                    processData: e.processData,
                                    beforeSend: function (e) {
                                        t.buttonLoader && o.length && o.loadingBtn(!0), t.beforeSubmit(e);
                                    },
                                    successSend: function (e) {
                                        t.successSubmit(e),
                                            t.buttonLoader && o.length && o.loadingBtn(!1),
                                            e.next_url &&
                                                setTimeout(function () {
                                                    document.location.href = e.next_url;
                                                }, 1500);
                                    },
                                    errorSend: function (e) {
                                        if ((t.buttonLoader && o.length && o.loadingBtn(!1), t.errorSubmit(e), t.validator && t.validator && e.error_fields)) {
                                            t.validator.resetForm();
                                            var n = e.messages;
                                            n[0] && delete n[0], t.validator.showErrors(n);
                                        }
                                    },
                                });
                        }),
                        (window.MyConfirm = function () {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                t = o().mixin({ customClass: { confirmButton: "btn btn-success", cancelButton: "btn btn-delete" }, buttonsStyling: !1 }),
                                n = { icon: "info", message: "", title: "", approveCallback: function () {}, rejectCallback: function () {}, approveText: c("check") + " بلی", rejectText: c("close") + " خیر" };
                            (n = Object.assign(n, e)),
                                t
                                    .fire({ title: n.title, text: n.message, icon: n.icon, showCancelButton: !0, confirmButtonColor: "#3085d6", cancelButtonColor: "#d33", confirmButtonText: n.approveText, cancelButtonText: n.rejectText })
                                    .then(function (e) {
                                        e.isConfirmed ? n.approveCallback() : n.rejectCallback();
                                    });
                        });
                });
                var m = function () {
                    $("body").tooltip({ selector: '[data-bs-toggle="tooltip"]' }),
                        $(document).on("keyup", '[data-separator="true"]', function (e) {
                            (e.which >= 37 && e.which <= 40) ||
                                $(this).val(function (e, t) {
                                    return (function (e) {
                                        return e ? (e = e.toString()).replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e;
                                    })(t);
                                });
                        }),
                        $(document).on("click", "#btn-toggle-theme", function () {
                            var e = $(this).attr("data-theme"),
                                t = "light";
                            (t = e && "light" != e ? "light" : "dark"), $("html").attr("data-bs-theme", t), $(this).attr("data-theme", t), $("#sidebarnav").attr("data-bs-theme", t);
                            var n = "dark" === t ? "" : "";
                            $(this).html(c(n)),
                                (function (e, t, n) {
                                    var a = "";
                                    if (n) {
                                        var o = new Date();
                                        o.setTime(o.getTime() + 24 * n * 60 * 60 * 1e3), (a = "; expires=" + o.toUTCString());
                                    }
                                    document.cookie = e + "=" + (t || "") + a + "; path=/";
                                })("panel-theme", t, 100);
                        }),
                        $(document).on("click", "[data-copy]", function () {
                            var e = $(this).attr("data-text");
                            e && l(e);
                        }),
                        $(document).on("click", ".btn-ajax-views", function (e) {
                            e.preventDefault(), e.stopPropagation();
                            var t = $(this).attr("data-url");
                            t &&
                                (function (e) {
                                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                                    $.ajaxRequest({
                                        url: baseUrl("ajax-views/" + e),
                                        data: t,
                                        type: "GET",
                                        dataType: "json",
                                        beforeSend: function (e) {
                                            var t = $("#modal-loading-body").html();
                                            $("#ajax-modal-view").html(t), $("#ajax-modal-view").modal("show");
                                        },
                                        successSend: function (e) {
                                            var t = e.html;
                                            $("#ajax-modal-view").html(t), $("#ajax-modal-view").modal("show");
                                        },
                                        errorSend: function (e) {
                                            u();
                                        },
                                    });
                                })(t);
                        }),
                        $(document).on("click", ".menu-toggle", function (e) {
                            e.preventDefault(), $("body").addClass("open-sidebar");
							e.preventDefault(), $("#toggle-mobile").removeClass("toggle-mobile-close");
                        }),
						$(document).on("click", "#toggle-pc", function (e) {
                            e.preventDefault(), $("body").addClass("open-sidebar");
							e.preventDefault(), $("#toggle-pc").addClass("toggle-pc");
							e.preventDefault(), $(".sidebarnav").removeClass("close");
                        }),
						$(document).on("click", ".toggle-pc", function (e) {
							e.preventDefault(), $(".sidebarnav").addClass("close");
                            e.preventDefault(), $("body").removeClass("open-sidebar");
							e.preventDefault(), $("#toggle-pc").removeClass("toggle-pc");
                        }),
                        $(document).on("click", ".switch-overlay", function (e) {
                            e.preventDefault(), $("body").removeClass("open-sidebar");
							e.preventDefault(), $("#toggle-pc").removeClass("toggle-pc");
                        }),
						$(document).on("click", "#toggle-mobile", function (e) {
                            e.preventDefault(), $(".sidebarnav").removeClass("close");
							e.preventDefault(), $("#toggle-mobile").addClass("toggle-mobile-close");
                        }),
						$(document).on("click", "#toggle-mobile.toggle-mobile-close", function (e) {
                            e.preventDefault(), $(".sidebarnav").addClass("close");
							e.preventDefault(), $("#toggle-mobile").removeClass("toggle-mobile-close");
                        }),
						$(document).on("click", ".switch-overlay", function (e) {
                            e.preventDefault(), $(".sidebarnav").addClass("close");
                        }),
                        $(document).on("click", ".form-password-toggle .toggle-icon", function (e) {
                            e.preventDefault();
                            var t = $(this).closest(".form-password-toggle"),
                                n = t.find("input"),
                                a = t.find(".toggle-icon");
                            "text" === n.attr("type") ? (n.attr("type", "password"), a.removeClass("fa-eye"), a.addClass("fa-eye-slash")) : (n.attr("type", "text"), a.removeClass("fa-eye-slash"), a.addClass("fa-eye"));
                        });
                };
                if ("dashboard" === activePage) {
                    $(".btn-reboot-server").click(function () {
                        window.MyConfirm({
                            icon: "warning",
                            message: "آیا مطمئن هستید؟",
                            title: "Reboot سیستم عامل",
                            approveCallback: function () {
                                w(function () {
                                    setTimeout(h, 700);
                                });
                            },
                        });
                    });
                    var w = function (e) {
                            var t = $(".btn-reboot-server").parents(".card");
                            $.ajaxRequest({
                                url: baseUrl("ajax/reboot-server"),
                                type: "POST",
                                beforeSend: function () {
                                    t.addClass("card-loading");
                                },
                                successSend: function (t) {
                                    e();
                                },
                                errorSend: function () {
                                    t.removeClass("card-loading");
                                },
                            });
                        },
                        h = function e() {
                            var t = $(".btn-reboot-server").parents(".card");
                            t.addClass("card-loading"),
                                $.ajax({
                                    url: baseUrl("ajax/is-ready"),
                                    type: "GET",
                                    timeout: 6e4,
                                    success: function (e) {
                                        t.removeClass("card-loading"),
                                            i("success", "سرور با موفقیت راه اندازی شد"),
                                            setTimeout(function () {
                                                location.reload();
                                            }, 800);
                                    },
                                    error: function (t, n, a) {
                                        e();
                                    },
                                });
                        };
                }
                if (
                    ("login" === activePage &&
                        $(function () {
                            $("#login-form").validate({
                                submitHandler: function () {
                                    $("#login-form").formSubmit({
                                        showNotify: !1,
                                        errorSubmit: function (e) {
                                            i("error", "نام کاربری یا رمز عبور شما اشتباه است");
                                        },
                                        successSubmit: function () {
                                            i("success", "ورود شما به پنل ادمین با موفقیت انجام شد");
                                        },
                                    });
                                },
                            });
                        }),
                    "settings" === activePage)
                ) {
                    var f = null;
                    $(function () {
                        f = $("#settings-form").validate({
                            rules: { fake_url: { url: !0 } },
                            submitHandler: function () {
                                $("#settings-form").formSubmit({
                                    validator: f,
                                    successSubmit: function () {
                                        i("success", "تنظیمات با موفقیت ذخیره شد");
                                    },
                                });
                            },
                        });
                    });
                }
                if ("backup" === activePage) {
                    var g = null;
                    $(function () {
                        $("#import-form").validate({
                            submitHandler: function () {
                                $("#import-form").formSubmit({
                                    formData: new FormData($("#import-form")[0]),
                                    processData: !1,
                                    contentType: !1,
                                    successSubmit: function (e) {
                                        var t = e.total_insert;
                                        t ? i("success", "تعداد ".concat(t, " کاربر با موفقیت اضافه شدند.")) : i("error", "متاسفانه هیچ کاربری اضافه نشد");
                                    },
                                });
                            },
                        }),
                            (g = $("#backup-table").dataTable({ lengthChange: !1, searching: !1, paging: !1, bInfo: !1 })),
                            $("#create-bkp-btn").click(function () {
                                var e = $(this);
                                $.ajaxRequest({
                                    url: baseUrl("ajax/settings/backup/export"),
                                    type: "post",
                                    beforeSend: function (t) {
                                        e.loadingBtn(!0);
                                    },
                                    successSend: function (t) {
                                        e.loadingBtn(!1), location.reload();
                                    },
                                });
                            }),
                            $(".btn-delete-bkp").click(function () {
                                var e = $(this).data("name");
                                window.MyConfirm({
                                    icon: "warning",
                                    message: "آیا مطمئن هستید؟",
                                    title: "حذف فایل پیشتبان",
                                    approveCallback: function () {
                                        b(e);
                                    },
                                });
                            });
                    });
                    var b = function (e) {
                        $.ajaxRequest({
                            url: baseUrl("ajax/settings/backup/export"),
                            type: "delete",
                            data: { filename: e },
                            successSend: function (t) {
                                var n = $(".bkp-row[data-name='".concat(e, "']"))[0];
                                g.fnDeleteRow(g.fnGetPosition(n));
                            },
                        });
                    };
                }
                if ("public_api" === activePage) {
                    var v = null;
                    $(function () {
                        $("#api-form").validate({
                            submitHandler: function () {
                                $("#api-form").formSubmit({
                                    successSubmit: function () {
                                        i("success", "توکن جدید با موفقیت افزوده شد"), v.fnDraw(!1), $("#api-form")[0].reset();
                                    },
                                });
                            },
                        }),
                            $("#btn-generate-token").click(function (e) {
                                e.preventDefault(), y();
                            }),
                            (v = $("#apis-table").dataTable({
                                processing: !0,
                                serverSide: !0,
                                ajax: { url: baseUrl("ajax/settings/public-api/list"), dataType: "json", type: "POST" },
                                order: [],
                                columns: [
                                    { title: "#", data: "idx", orderable: !1, searchable: !1 },
                                    { title: "نام", data: "name", orderable: !1, searchable: !0 },
                                    { title: "توکن", data: "api_key", orderable: !1, searchable: !0 },
                                    { title: "زمان ایجاد", data: "ctime", orderable: !1, searchable: !1 },
                                    {
                                        title: "تنظیمات",
                                        data: "opr",
                                        orderable: !1,
                                        searchable: !1,
                                        render: function (e, t, n) {
                                            return '<button type="button" class="btn btn-icons btn-delete"  data-id="'.concat(n.id, '" >').concat(c("trash"), "</button>");
                                        },
                                    },
                                ],
                            })),
                            $(document).on("click", ".btn-delete", function (e) {
                                e.preventDefault();
                                var t = $(this).data("id");
                                window.MyConfirm({
                                    icon: "warning",
                                    message: "آیا مطمئن هستید؟",
                                    title: "حذف ردیف API",
                                    approveCallback: function () {
                                        x(t, function () {
                                            i("success", "ردیف مورد نظر با موفقیت حذف شد"), v.fnDraw(!1);
                                        });
                                    },
                                });
                            });
                    });
                    var y = function () {
                            var e = d(30);
                            $("input[name=token]").val(e);
                        },
                        x = function (e, t) {
                            $.ajaxRequest({
                                url: baseUrl("ajax/settings/public-api/".concat(e)),
                                type: "delete",
                                successSend: function (e) {
                                    t(e);
                                },
                            });
                        };
                }
                if ("filtering" === activePage) {
                    $(function () {
                        k();
                    });
                    var k = function () {
                        $.ajaxRequest({
                            url: baseUrl("ajax/pages/filtering"),
                            type: "get",
                            showNotify: !1,
                            successSend: function (e) {
                                var t = "";
                                e.map(function (e) {
                                    (t += "<div class='border-bottom mb-1 py-2'>"),
                                        (t += "<div class='d-flex justify-content-between'>"),
                                        (t += '<span><img class="me-2" src=\''.concat(e.flag_img, "'/> ").concat(e.name, "</span>")),
                                        "online" === e.status
                                            ? (t += '<small class="bg-success text-white rounded py-1 px-2 fw-bold">آنلاین</small>')
                                            : (t += '<small class="bg-danger text-white rounded py-1 px-2 fw-bold">فیلتر شده</small>'),
                                        (t += "</div>"),
                                        (t += "</div>");
                                }),
                                    $("#result-filtering").html(t);
                            },
                            errorSend: function (e) {
                                $("#result-filtering").html("<div class='alert alert-warning'>متاسفانه نتیجه با خطا روبرو شد دوباره تلاش کنید</div>");
                            },
                        });
                    };
                }
                if ("users_panel" === activePage) {
                    f = null;
                    $(function () {
                        f = $("#settings-form").validate({
                            submitHandler: function () {
                                $("#settings-form").formSubmit({
                                    validator: f,
                                    successSubmit: function () {
                                        i("success", "تنظیمات با موفقیت ذخیره شد");
                                    },
                                });
                            },
                        });
                    });
                }
				if ("users" === activePage) {
                    var C = null;
                    $(function () {
                        T(), (window.initUsersForm = A), (window.initBulkForm = B);
                    });
                    var A = function (e) {
                            var t;
                            "add" === e && S(),
                                $("#btn-generate-pass").click(function (e) {
                                    S();
                                }),
                                $(".datepicker").datepicker({ isRTL: !0, dateFormat: "yy/mm/dd" }),
                                $("input[name=expiry_type]").change(function () {
                                    "date" === $(this).val()
                                        ? ($("#expiry-by-date").show(), $("#expiry-by-days").hide(), $("input[name=exp_days]").val(""))
                                        : ($("#expiry-by-days").show(), $("#expiry-by-date").hide(), $("input[name=exp_date]").val(""));
                                }),
                                (t = $("#user-form").validate({
                                    rules: { password: { password: !0 }, username: { username: !0 }, mobile: { irMobile: !0 } },
                                    submitHandler: function () {
                                        $("#user-form").formSubmit({
                                            validator: t,
                                            submitBtn: $("#btn-submit-user"),
                                            successSubmit: function () {
                                                u();
                                                var t = "کاربر جدید با موفقیت افروده شد";
                                                "edit" === e && (t = "کاربر مورد نظر با موفقیت ویرایش شد"), i("success", t), C && C.fnDraw(!1);
                                            },
                                        });
                                    },
                                }));
                        },
                        S = function () {
                            var e = d(7);
                            $("input[name=password]").val(e);
                        },
                        j = function () {
                            $(".user-chk-selected:checked").length > 0 ? $("#btn-bulk-delete , #btn-bulk-del").show() : $("#btn-bulk-delete , #btn-bulk-del").hide();
                        },
                        T = function () {
                            var e;
                            (C = $("#users-table").dataTable({
                                processing: !0,
                                serverSide: !0,
                                responsive: !0,
                                pageLength: tablePageLength,
                                ajax: {
                                    url: baseUrl("ajax/users/list"),
                                    dataType: "json",
                                    type: "POST",
                                    data: function (e) {
                                        $("#filtering-form input , #filtering-form select").each(function () {
                                            var t = $(this).attr("name");
                                            if (t) {
                                                var n = $(this).val();
                                                e[t] = n;
                                            }
                                        }),
                                            activeStatus && (e.status = activeStatus);
                                    },
                                },
                                fnDrawCallback: function () {
                                    if ((j(), activeStatus)) {
                                        $('#filtering-form select[name="status"]').val(activeStatus), (activeStatus = null);
                                        var e = window.location.origin + window.location.pathname;
                                        window.history.replaceState(null, null, e);
                                    }
                                },
                                order: [[0, "desc"]],
                                columns: [
                                    {
                                        title: '<div class="form-check"><input class="form-check-input" id="check-all-users" type="checkbox" ></div>',
                                        data: "id",
                                        width: "20px",
                                        orderable: !1,
                                        searchable: !1,
                                        render: function (e, t, n) {
                                            var a = '<div class="form-check">';
                                            return (a += '<input class="form-check-input  user-chk-selected" type="checkbox" >'), (a += '<label class="form-check-label">'.concat(n.idx, "</label>")), (a += "</div>");
                                        },
                                    },
									{	// نام کاربری / رمز
                                        title: "****",
                                        data: "username",
                                        orderable: !0,
                                        searchable: !0,
                                        render: function (e, t, n) {
                                            var a = n.password,
                                                o = "<div>";
                                            return (
                                                (o += '<span class="d-block mb-0 fw-bold">'.concat(e, "</span>")),
                                                (o += "</div>")
                                            );
                                        },
                                    },
									{	// نام کاربری / رمز
                                        title: "****",
                                        data: "password",
                                        orderable: !0,
                                        searchable: !0,
                                        render: function (e, t, n) {
                                            var a = n.password,
                                                o = "<div>";
                                            return (
                                                (o += '<div class="text-muted">'),
                                                (o += "<span class=\"cursor-pointer\" data-copy='true' data-text='".concat(a, "' data-bs-toggle='tooltip' title=\"کپی رمز\">").concat(c("copy"), "</span>")),
                                                (o += '<span class="d-inlin-block me-1" >'.concat(n.password, "</span>")),
                                                (o += "</div>")
                                            );
                                        },
                                    },
                                    {	// حجم مصرفی
										title: "<i class='fa fa-battery-half icon menu-icon icon'></i>",
										data: "traffic",
										orderable: !0,
										searchable: !1,
										render: function (e, t, n) {
											var a = n.consumer_traffic,
												o = n.traffic,
												s = n.traffic_format,
												r = n.consumer_traffic_format,
												i = Math.floor((100 * a) / o),
                                                l = '<div  class="text-muted" style="font-size:13px" >'.concat(r, " </div>");
                                            return (
                                                (l += '<div class="progress text-primary-emphasis rounded-pill position-relative" style="height: 8px;">'),
                                                (l += '<div class="progress-bar bg-success" style="width:'.concat(i, '%"></div>')),
                                                (l += "</div>")
                                            );
                                        },
                                    },
                                    {	// مدت زمان
                                        title: "<i class='fa fa-clock icon menu-icon icon'></i>",
                                        data: "remaining_days",
                                        orderable: !1,
                                        searchable: !1,
                                        render: function (e, t, n) {
                                            var a = "";
                                            if (n.diffrence_date)
                                                if (((a = "<div class='text-center'>"), (a += "<div class='badge mb-1 bg-primary-subtle text-primary-emphasis'>".concat(n.diffrence_date, "</div>")), e >= 0))
                                                    a += '<small class="d-block text-muted" style="min-width:80px">'.concat(e, " روز</small>");
                                                else {
													var o = Math.abs(e);
                                                    a += "<small class='d-block text-danger'>".concat(o, " - </small>");
                                                }
                                            else a = "<div class='text-center'>-</div>";
                                            return (a += "</div>");
                                        },
                                    },
									{ title: "<i class='fa fa-user icon menu-icon icon'></i>", data: "limit_users", width: "40px", orderable: !0, searchable: !1 },
                                    {	// وضعیت اتصال
                                        title: "<i class='fa fa-genderless icon menu-icon icon genderless-left'></i>",
                                        data: "online_users",
										width: "40px",
                                        orderable: !1,
                                        searchable: !1,
                                        render: function (e, t, n) {
                                            var a = n.limit_users,
                                                o = e.length,
                                                s = JSON.stringify(e),
                                                r = window.btoa(s),
                                                i = "btn-show-onlines badge py-2 px-3 cursor-pointer rounded-pill ";
                                            return (
                                                e.length ? (i += "bg-success text-success-emphasis") : (i += "text-body-secondary so-userOnline-badge"),
												'<span data-users="'.concat(r, '" class="').concat(i, '"> ').concat(o, " </span>")
                                            );
                                        },
                                    },
                                    {	// وضعیت
                                        title: "<i class='fa fa-shield-alt icon menu-icon icon'></i>", 
                                        data: "status",
                                        orderable: !1,
                                        searchable: !1,
                                        render: function (e, t, n) {
                                            var a = "badge px-2 rounded";
                                            return "de_active" === e
												? '<span class="'.concat(a, ' bg-warning-subtle text-warning-emphasis badge"><i class="fa fa-exclamation-circle"></i></span>')
												: "active" === e
												? '<span class="'.concat(a, ' bg-success-subtle text-success-emphasis" ><i class="fa fa-check-circle"></i></span>')
												: '<span class="'.concat(a, ' bg-danger-subtle  text-danger-emphasis" >').concat(n.status_label, "<i class='fa fa-times-circle'></i></span>");
                                        },
                                    },
                                    {	// موبایل
                                        title: "<i class='fa fa-mobile icon menu-icon icon'></i>",
                                        data: "mobilebrand",
										width: "40px",
                                        orderable: !1,
                                        searchable: !1,
                                        render: function (e) {
                                            return e ? '<small class="'.concat(e, '-phone-info"><i class="fab fa-apple icon menu-icon icon iPhone-phone-img phone-img-info" width="30"></i><i class="fab fa-android icon menu-icon icon Android-phone-img phone-img-info" width="30"></i></small>') : "-";
                                        },
                                    },
									{	// سیمکارت
                                        title: "<i class='fa fa-sim-card icon menu-icon icon'></i>",
                                        data: "operator",
										width: "40px",
                                        orderable: !1,
                                        searchable: !1,
                                        render: function (e) {
											return e ? '<small class="'.concat(e, '-sim-info"><img src="assets/images/mci.svg" class="HamrahAval-sim-img sim-img-info" width="30" /><img src="assets/images/mtn.svg" class="Irancell-sim-img sim-img-info" width="30" /></small>') : "-";
                                        },
                                    },
                                    {	// عملیات
                                        title: "<i class='fa fa-gear icon menu-icon icon'></i>",
                                        data: "opr",
										width: "172px",
                                        orderable: !1,
                                        searchable: !1,
                                        render: function (e, t, n) {
                                            var a = "users/".concat(n.id, "/edit"),
                                                o = "users/".concat(n.id, "/info"),
                                                s = "rounded-circle btn btn-icons btn-sm btn-Square",
                                                r = c("pencil"),
                                                i = c("trash"),
                                                l = c("address-card"),
                                                d = c("arrows-rotate"),
                                                u = "<div class='btn-items btn-Squares' style=\"min-width:150px\">";
                                            return (
                                                (u += '<button type="button" class="'.concat(s, ' btn-ajax-views btn-action btn-ajax-views-a btn-normal" title="ویرایش" data-url="').concat(a, '">').concat(r, "</button>")),
                                                (u += '<button type="button" class="'.concat(s, ' btn-renewal btn-action btn-normal"  title="تمدید"  data-id="').concat(n.id, '" >').concat(d, "</button>")),
                                                (u += '<button type="button" class="'.concat(s, ' btn-ajax-views btn-action btn-ajax-views-b btn-normal"  title="اطلاعات کامل" data-url="').concat(o, '" >').concat(l, "</button>")),
                                                (u += '<button type="button" class="'.concat(s, ' btn-delete btn-action btn-Square-delete btn-normal"  title="حذف"  data-id="').concat(n.id, '" >').concat(i, "</button>")),
                                                (u += "</div>")
                                            );
                                        },
                                    },
                                ],
                            })),
                                $(document).on("change", "#filtering-form", function (e) {
                                    $(e.target).attr("name") && C.fnDraw(!1);
                                }),
                                $(document).on("input", "#filtering-form input[name=main_search]", function () {
                                    clearTimeout(e),
                                        (e = setTimeout(function () {
                                            C.fnDraw(!1);
                                        }, 500));
                                }),
                                $(document).on("click", ".user-chk-selected", function (e) {
                                    var t = $(this).prop("checked");
                                    $(this).closest("tr").toggleClass("selected", t),
                                        $(".user-chk-selected:checked").length === $(".user-chk-selected").length
                                            ? ($("#check-all-users").prop("checked", !0), $("#check-all-users").prop("indeterminate", !1))
                                            : 0 === $(".user-chk-selected:checked").length
                                            ? ($("#check-all-users").prop("checked", !1), $("#check-all-users").prop("indeterminate", !1))
                                            : ($("#check-all-users").prop("checked", !1), $("#check-all-users").prop("indeterminate", !0)),
                                        j();
                                }),
                                $(document).on("click", ".btn-show-onlines", function (e) {
                                    var t = $(this).data("users");
                                    if (t)
                                        try {
                                            (t = window.atob(t)), (t = JSON.parse(t));
                                        } catch (e) {
                                            console.log(e);
                                        }
                                }),
                                $(document).on("click", "#check-all-users", function (e) {
                                    var t = $(this).prop("checked");
                                    $(".user-chk-selected")
                                        .prop("checked", t)
                                        .each(function () {
                                            $(this).closest("tr").toggleClass("selected", t);
                                        }),
                                        $(".user-chk-selected").prop("checked", t),
                                        $(".user-chk-selected:checked").length > 0 && $(".user-chk-selected:not(:checked)").length > 0 ? $(this).prop("indeterminate", !0) : $(this).prop("indeterminate", !1),
                                        j();
                                }),
                                C.on("click", ".btn-delete", function (e) {
                                    e.preventDefault(), e.stopPropagation();
                                    var t = $(this).data("id");
                                    window.MyConfirm({
                                        icon: "warning",
                                        message: "آیا مطمئن هستید؟ این عملیات قابل بازگشت نیست",
                                        title: "حذف کاربر",
                                        approveCallback: function () {
                                            var e, n, a;
                                            (e = t),
                                                (n = function () {
                                                    C.fnDraw(!1), i("success", "کاربر مورد نظر با موفقیت حذف شد");
                                                }),
                                                (a = $(".btn-delete[data-id='".concat(e, "']"))),
                                                $.ajaxRequest({
                                                    url: baseUrl("ajax/users/".concat(e)),
                                                    type: "delete",
                                                    beforeSend: function () {
                                                        a.loadingBtn(!0);
                                                    },
                                                    successSend: function (e) {
                                                        a.loadingBtn(!1), n(e);
                                                    },
                                                    errorSend: function () {
                                                        a.loadingBtn(!1);
                                                    },
                                                });
                                        },
                                    });
                                }),
                                C.on("click", ".btn-renewal", function (e) {
                                    e.preventDefault(), e.stopPropagation();
                                    var t = $(this).data("id");
                                    P(t);
                                }),
                                $(document).on("click", "#btn-bulk-delete", function (e) {
                                    e.preventDefault(), e.stopPropagation();
                                    var t = C.api().rows(".selected"),
                                        n = [];
                                    t.data().map(function (e) {
                                        e.id && n.push(e.id);
                                    }),
                                        window.MyConfirm({
                                            icon: "warning",
                                            message: "آیا مطمئن هستید؟ این عملیات قابل بازگشت نیست",
                                            title: "حذف تعداد ".concat(n.length, " کاربر"),
                                            approveCallback: function () {
                                                !(function (e, t) {
                                                    var n = $("#btn-bulk-delete");
                                                    $.ajaxRequest({
                                                        url: baseUrl("ajax/users/bulk/delete"),
                                                        type: "post",
                                                        data: { users: e },
                                                        beforeSend: function () {
                                                            n.loadingBtn(!0);
                                                        },
                                                        successSend: function (e) {
                                                            n.loadingBtn(!1), t(e);
                                                        },
                                                        errorSend: function () {
                                                            n.loadingBtn(!1);
                                                        },
                                                    });
                                                })(n, function () {
                                                    C.fnDraw(!1), i("success", "کاربران انتخابی مورد نظر با موفقیت حذف شدند"), $("#check-all-users").prop("checked", !1), $("#check-all-users").prop("indeterminate", !1), j();
                                                });
                                            },
                                        });
                                }),
                                $(document).on("click", ".btn-chng-active", function (e) {
                                    e.preventDefault();
                                    var t = $(this),
                                        n = $(this).data("id"),
                                        a = parseInt($(this).attr("data-active")),
                                        o = a ? "غیر فعال کردن" : "فعال کردن",
                                        s = a ? "آیا می خواهید کاربر مورد نظر را غیر فعال کنید؟" : "آیا می خواهید کاربر مورد نظر را فعال کنید؟";
                                    window.MyConfirm({
                                        icon: "warning",
                                        message: s,
                                        title: o,
                                        approveCallback: function () {
                                            var e, o, s;
                                            (e = n),
                                                (o = function () {
                                                    if ((t.attr("data-active", a ? 0 : 1), a))
                                                        t.removeClass("btn-warning").addClass("btn-success"), (e = "فعال کردن" + c("play")), t.html(e), i("success", "کاربر مورد نظر با موفقیت غیر فعال شد");
                                                    else {
                                                        t.removeClass("btn-success").addClass("btn-warning");
                                                        var e = "غیر فعال کردن" + c("pause");
                                                        t.html(e), i("success", "کاربر مورد نظر با موفقیت فعال شد");
                                                    }
                                                    C.fnDraw(!1);
                                                }),
                                                (s = $(".btn-chng-active")),
                                                $.ajaxRequest({
                                                    url: baseUrl("ajax/users/".concat(e, "/toggle-active")),
                                                    type: "put",
                                                    beforeSend: function () {
                                                        s.loadingBtn(!0);
                                                    },
                                                    successSend: function (e) {
                                                        s.loadingBtn(!1), o(e);
                                                    },
                                                    errorSend: function () {
                                                        s.loadingBtn(!1);
                                                    },
                                                });
                                        },
                                    });
                                }),
                                $(document).on("click", ".btn-reset-traffic", function (e) {
                                    e.preventDefault();
                                    var t = $(this).data("id");
                                    window.MyConfirm({
                                        icon: "warning",
                                        message: "آیا مطمئن هستید؟",
                                        title: "ریست کردن ترافیک",
                                        approveCallback: function () {
                                            var e, n, a;
                                            (e = t),
                                                (n = function () {
                                                    C.fnDraw(!1), i("success", "ریست ترافیک کاربر با موفقیت انجام شد"), $("#spn-user-traffic").html("-");
                                                }),
                                                (a = $(".btn-reset-traffic")),
                                                $.ajaxRequest({
                                                    url: baseUrl("ajax/users/".concat(e, "/reset-traffic")),
                                                    type: "put",
                                                    beforeSend: function () {
                                                        a.loadingBtn(!0);
                                                    },
                                                    successSend: function (e) {
                                                        a.loadingBtn(!1), n(e);
                                                    },
                                                    errorSend: function () {
                                                        a.loadingBtn(!1);
                                                    },
                                                });
                                        },
                                    });
                                }),
                                $(document).on("click", ".btn-copy-config", function (e) {
                                    e.preventDefault();
                                    var t = $(this).data("config"),
                                        n = "Host: ".concat(t.host, "\n");
                                    (n += "Username: ".concat(t.username, "\n")),
                                        (n += "Password: ".concat(t.password, "\n")),
                                        (n += "SSH Port: ".concat(t.ssh_port, "\n")),
                                        (n += "UDP Port: ".concat(t.udp_port, "\n")),
                                        (n += "Start Date: ".concat(t.start_date, "\n")),
                                        (n += "End Date: ".concat(t.end_date, "\n")),
                                        (n += "Public Link: ".concat(t.public_link)),
                                        l(n);
                                });
                        },
                        B = function () {
                            var e;
                            $(".datepicker").datepicker({ isRTL: !0, dateFormat: "yy/mm/dd" }),
                                $("input[name=expiry_type]").change(function () {
                                    "date" === $(this).val()
                                        ? ($("#expiry-by-date").show(), $("#expiry-by-days").hide(), $("input[name=exp_days]").val(""))
                                        : ($("#expiry-by-days").show(), $("#expiry-by-date").hide(), $("input[name=exp_date]").val(""));
                                }),
                                (e = $("#bulk-users-form").validate({
                                    rules: { prefix_username: { prefixUname: !0, minlength: 3 } },
                                    submitHandler: function () {
                                        $("#bulk-users-form").formSubmit({
                                            validator: e,
                                            submitBtn: $("#btn-submit-bulk-users"),
                                            successSubmit: function (e) {
                                                var t = e.messages;
                                                i("success", t), u(), C && C.fnDraw(!1);
                                            },
                                        });
                                    },
                                }));
                        },
                        P = function (e) {
                            $("#renewal-users-modal").modal("show");
                            var t,
                                n = baseUrl("ajax/users/".concat(e, "/renewal"));
                            $("#renewal-users-form").attr("action", n),
                                (t = $("#renewal-users-form").validate({
                                    submitHandler: function () {
                                        $("#renewal-users-form").formSubmit({
                                            validator: t,
                                            submitBtn: $("#btn-submit-renewal"),
                                            successSubmit: function () {
                                                $("#renewal-users-modal").modal("hide"), $("#renewal-users-form")[0].reset(), C.fnDraw(!1);
                                            },
                                        });
                                    },
                                }));
                        };
                }
				if (
					("online-users" === activePage &&
						$(function () {
							$("#online-users-table").dataTable({ pageLength: 100 }),
								$(".btn-kill-user").click(function (t) {
									t.preventDefault();
									var n = $(this).attr("data-pid").split(",");
									window.MyConfirm({
										icon: "warning",
										message: "آیا مطمئن هستید؟",
										title: "اخراج کاربر",
										approveCallback: function () {
											e(n);
										},
									});
								});
							var e = function (e) {
								$.ajaxRequest({
									url: baseUrl("ajax/users/kill-pid"),
									type: "post",
									data: { pids: e },
									successSend: function (e) {
										location.reload();
									},
								});
							};
						}),
					"admins" === activePage)
				) {
                    var E = null;
                    $(function () {
                        D(), (window.initAdminForm = L);
                    });
                    var D = function () {
                            $(document).ready(function () {
                                (E = $("#admins-table").dataTable({
                                    processing: !0,
                                    serverSide: !0,
                                    ajax: { url: baseUrl("ajax/admins/list"), dataType: "json", type: "POST" },
                                    columns: [
                                        {
                                            title: "#",
                                            data: "id",
                                            orderable: !0,
                                            searchable: !1,
                                            render: function (e, t, n) {
                                                return n.idx;
                                            },
                                        },
                                        { title: "نام کاربری", data: "username", orderable: !1, searchable: !0 },
                                        { title: "نام کامل", data: "fullname", orderable: !1, searchable: !0 },
                                        {
                                            title: "وضعیت",
                                            data: "is_active",
                                            orderable: !1,
                                            searchable: !1,
                                            render: function (e) {
                                                var t = '<span class="bg-success text-white px-2" style="opacity:0.6">فعال</span>';
                                                return e || (t = '<span class="bg-warning text-white px-2" style="opacity:0.7">غیر فعال</span>'), t;
                                            },
                                        },
                                        {
                                            title: "تنظیمات",
                                            data: "opr",
                                            orderable: !1,
                                            searchable: !1,
                                            render: function (e, t, n) {
                                                var a = "admins/".concat(n.id, "/edit"),
                                                    o = "<div class='btn-items'>";
                                                return (
                                                    (o += '<button type="button" class="btn btn-icons btn-Square btn-Square-normal btn-ajax-views" data-url="'.concat(a, '">').concat(c("pencil"), "</button>")),
                                                    (o += '<button type="button" class="btn btn-icons btn-Square btn-Square-normal btn-margin btn-delete" data-id="'.concat(n.id, '" >').concat(c("trash"), "</button>")),
                                                    (o += "</div>")
                                                );
                                            },
                                        },
                                    ],
                                    order: [0, "DESC"],
                                })),
                                    $(document).on("click", ".btn-delete", function (t) {
                                        t.preventDefault();
                                        var n = $(this).data("id");
                                        window.MyConfirm({
                                            icon: "warning",
                                            message: "آیا مطمئن هستید؟ این عملیات قابل بازگشت نیست",
                                            title: "حذف کاربر",
                                            approveCallback: function () {
                                                e(n, function () {
                                                    E.fnDraw(!1), i("success", "کاربر مورد نظر با موفقیت حذف شد");
                                                });
                                            },
                                        });
                                    });
                                var e = function (e, t) {
                                    $.ajaxRequest({
                                        url: baseUrl("ajax/admins/".concat(e)),
                                        type: "delete",
                                        successSend: function (e) {
                                            t(e);
                                        },
                                    });
                                };
                            });
                        },
                        L = function (e) {
                            var t,
                                n = function () {
                                    var e = d(8);
                                    $("input[name=password]").val(e);
                                };
                            "add" === e && n(),
                                $("#btn-generate-pass").click(function (e) {
                                    n();
                                }),
                                (t = $("#user-form").validate({
                                    rules: { password: { checkPassword: !0 }, username: { enName: !0 } },
                                    submitHandler: function () {
                                        $("#user-form").formSubmit({
                                            validator: t,
                                            successSubmit: function () {
                                                u();
                                                var t = "کاربر جدید با موفقیت افروده شد";
                                                "edit" === e && (t = "کاربر مورد نظر با موفقیت ویرایش شد"), i("success", t), E && E.fnDraw(!1);
                                            },
                                        });
                                    },
                                }));
                        };
                }
            },
            640: (e, t, n) => {
                "use strict";
                var a = n(742),
                    o = { "text/plain": "Text", "text/html": "Url", default: "Text" };
                e.exports = function (e, t) {
                    var n,
                        s,
                        r,
                        i,
                        l,
                        c,
                        d = !1;
                    t || (t = {}), (n = t.debug || !1);
                    try {
                        if (
                            ((r = a()),
                            (i = document.createRange()),
                            (l = document.getSelection()),
                            ((c = document.createElement("span")).textContent = e),
                            (c.ariaHidden = "true"),
                            (c.style.all = "unset"),
                            (c.style.position = "fixed"),
                            (c.style.top = 0),
                            (c.style.clip = "rect(0, 0, 0, 0)"),
                            (c.style.whiteSpace = "pre"),
                            (c.style.webkitUserSelect = "text"),
                            (c.style.MozUserSelect = "text"),
                            (c.style.msUserSelect = "text"),
                            (c.style.userSelect = "text"),
                            c.addEventListener("copy", function (a) {
                                if ((a.stopPropagation(), t.format))
                                    if ((a.preventDefault(), void 0 === a.clipboardData)) {
                                        n && console.warn("unable to use e.clipboardData"), n && console.warn("trying IE specific stuff"), window.clipboardData.clearData();
                                        var s = o[t.format] || o.default;
                                        window.clipboardData.setData(s, e);
                                    } else a.clipboardData.clearData(), a.clipboardData.setData(t.format, e);
                                t.onCopy && (a.preventDefault(), t.onCopy(a.clipboardData));
                            }),
                            document.body.appendChild(c),
                            i.selectNodeContents(c),
                            l.addRange(i),
                            !document.execCommand("copy"))
                        )
                            throw new Error("copy command was unsuccessful");
                        d = !0;
                    } catch (a) {
                        n && console.error("unable to copy using execCommand: ", a), n && console.warn("trying IE specific stuff");
                        try {
                            window.clipboardData.setData(t.format || "text", e), t.onCopy && t.onCopy(window.clipboardData), (d = !0);
                        } catch (a) {
                            n && console.error("unable to copy using clipboardData: ", a),
                                n && console.error("falling back to prompt"),
                                (s = (function (e) {
                                    var t = (/mac os x/i.test(navigator.userAgent) ? "⌘" : "Ctrl") + "+C";
                                    return e.replace(/#{\s*key\s*}/g, t);
                                })("message" in t ? t.message : "Copy to clipboard: #{key}, Enter")),
                                window.prompt(s, e);
                        }
                    } finally {
                        l && ("function" == typeof l.removeRange ? l.removeRange(i) : l.removeAllRanges()), c && document.body.removeChild(c), r();
                    }
                    return d;
                };
            },
            611: () => {},
            455: function (e) {
                (e.exports = (function () {
                    "use strict";
                    const e = 100,
                        t = {},
                        n = () => {
                            t.previousActiveElement instanceof HTMLElement ? (t.previousActiveElement.focus(), (t.previousActiveElement = null)) : document.body && document.body.focus();
                        },
                        a = (a) =>
                            new Promise((o) => {
                                if (!a) return o();
                                const s = window.scrollX,
                                    r = window.scrollY;
                                (t.restoreFocusTimeout = setTimeout(() => {
                                    n(), o();
                                }, e)),
                                    window.scrollTo(s, r);
                            });
                    var o = { promise: new WeakMap(), innerParams: new WeakMap(), domCache: new WeakMap() };
                    const s = "swal2-",
                        r = [
                            "container",
                            "shown",
                            "height-auto",
                            "iosfix",
                            "popup",
                            "modal",
                            "no-backdrop",
                            "no-transition",
                            "toast",
                            "toast-shown",
                            "show",
                            "hide",
                            "close",
                            "title",
                            "html-container",
                            "actions",
                            "confirm",
                            "deny",
                            "cancel",
                            "default-outline",
                            "footer",
                            "icon",
                            "icon-content",
                            "image",
                            "input",
                            "file",
                            "range",
                            "select",
                            "radio",
                            "checkbox",
                            "label",
                            "textarea",
                            "inputerror",
                            "input-label",
                            "validation-message",
                            "progress-steps",
                            "active-progress-step",
                            "progress-step",
                            "progress-step-line",
                            "loader",
                            "loading",
                            "styled",
                            "top",
                            "top-start",
                            "top-end",
                            "top-left",
                            "top-right",
                            "center",
                            "center-start",
                            "center-end",
                            "center-left",
                            "center-right",
                            "bottom",
                            "bottom-start",
                            "bottom-end",
                            "bottom-left",
                            "bottom-right",
                            "grow-row",
                            "grow-column",
                            "grow-fullscreen",
                            "rtl",
                            "timer-progress-bar",
                            "timer-progress-bar-container",
                            "scrollbar-measure",
                            "icon-success",
                            "icon-warning",
                            "icon-info",
                            "icon-question",
                            "icon-error",
                        ].reduce((e, t) => ((e[t] = s + t), e), {}),
                        i = ["success", "warning", "info", "question", "error"].reduce((e, t) => ((e[t] = s + t), e), {}),
                        l = "SweetAlert2:",
                        c = (e) => e.charAt(0).toUpperCase() + e.slice(1),
                        d = (e) => {
                            console.warn(`${l} ${"object" == typeof e ? e.join(" ") : e}`);
                        },
                        u = (e) => {
                            console.error(`${l} ${e}`);
                        },
                        p = [],
                        m = (e) => {
                            p.includes(e) || (p.push(e), d(e));
                        },
                        w = (e, t) => {
                            m(`"${e}" is deprecated and will be removed in the next major release. Please use "${t}" instead.`);
                        },
                        h = (e) => ("function" == typeof e ? e() : e),
                        f = (e) => e && "function" == typeof e.toPromise,
                        g = (e) => (f(e) ? e.toPromise() : Promise.resolve(e)),
                        b = (e) => e && Promise.resolve(e) === e,
                        v = () => document.body.querySelector(`.${r.container}`),
                        y = (e) => {
                            const t = v();
                            return t ? t.querySelector(e) : null;
                        },
                        x = (e) => y(`.${e}`),
                        k = () => x(r.popup),
                        $ = () => x(r.icon),
                        C = () => x(r["icon-content"]),
                        A = () => x(r.title),
                        S = () => x(r["html-container"]),
                        j = () => x(r.image),
                        T = () => x(r["progress-steps"]),
                        B = () => x(r["validation-message"]),
                        P = () => y(`.${r.actions} .${r.confirm}`),
                        E = () => y(`.${r.actions} .${r.cancel}`),
                        D = () => y(`.${r.actions} .${r.deny}`),
                        L = () => x(r["input-label"]),
                        O = () => y(`.${r.loader}`),
                        M = () => x(r.actions),
                        _ = () => x(r.footer),
                        z = () => x(r["timer-progress-bar"]),
                        q = () => x(r.close),
                        H =
                            '\n  a[href],\n  area[href],\n  input:not([disabled]),\n  select:not([disabled]),\n  textarea:not([disabled]),\n  button:not([disabled]),\n  iframe,\n  object,\n  embed,\n  [tabindex="0"],\n  [contenteditable],\n  audio[controls],\n  video[controls],\n  summary\n',
                        I = () => {
                            const e = k();
                            if (!e) return [];
                            const t = e.querySelectorAll('[tabindex]:not([tabindex="-1"]):not([tabindex="0"])'),
                                n = Array.from(t).sort((e, t) => {
                                    const n = parseInt(e.getAttribute("tabindex") || "0"),
                                        a = parseInt(t.getAttribute("tabindex") || "0");
                                    return n > a ? 1 : n < a ? -1 : 0;
                                }),
                                a = e.querySelectorAll(H),
                                o = Array.from(a).filter((e) => "-1" !== e.getAttribute("tabindex"));
                            return [...new Set(n.concat(o))].filter((e) => se(e));
                        },
                        U = () => F(document.body, r.shown) && !F(document.body, r["toast-shown"]) && !F(document.body, r["no-backdrop"]),
                        R = () => {
                            const e = k();
                            return !!e && F(e, r.toast);
                        },
                        N = () => {
                            const e = k();
                            return !!e && e.hasAttribute("data-loading");
                        },
                        V = (e, t) => {
                            if (((e.textContent = ""), t)) {
                                const n = new DOMParser().parseFromString(t, "text/html"),
                                    a = n.querySelector("head");
                                a &&
                                    Array.from(a.childNodes).forEach((t) => {
                                        e.appendChild(t);
                                    });
                                const o = n.querySelector("body");
                                o &&
                                    Array.from(o.childNodes).forEach((t) => {
                                        t instanceof HTMLVideoElement || t instanceof HTMLAudioElement ? e.appendChild(t.cloneNode(!0)) : e.appendChild(t);
                                    });
                            }
                        },
                        F = (e, t) => {
                            if (!t) return !1;
                            const n = t.split(/\s+/);
                            for (let t = 0; t < n.length; t++) if (!e.classList.contains(n[t])) return !1;
                            return !0;
                        },
                        Z = (e, t) => {
                            Array.from(e.classList).forEach((n) => {
                                Object.values(r).includes(n) || Object.values(i).includes(n) || Object.values(t.showClass || {}).includes(n) || e.classList.remove(n);
                            });
                        },
                        Q = (e, t, n) => {
                            if ((Z(e, t), t.customClass && t.customClass[n])) {
                                if ("string" != typeof t.customClass[n] && !t.customClass[n].forEach) return void d(`Invalid type of customClass.${n}! Expected string or iterable object, got "${typeof t.customClass[n]}"`);
                                X(e, t.customClass[n]);
                            }
                        },
                        Y = (e, t) => {
                            if (!t) return null;
                            switch (t) {
                                case "select":
                                case "textarea":
                                case "file":
                                    return e.querySelector(`.${r.popup} > .${r[t]}`);
                                case "checkbox":
                                    return e.querySelector(`.${r.popup} > .${r.checkbox} input`);
                                case "radio":
                                    return e.querySelector(`.${r.popup} > .${r.radio} input:checked`) || e.querySelector(`.${r.popup} > .${r.radio} input:first-child`);
                                case "range":
                                    return e.querySelector(`.${r.popup} > .${r.range} input`);
                                default:
                                    return e.querySelector(`.${r.popup} > .${r.input}`);
                            }
                        },
                        W = (e) => {
                            if ((e.focus(), "file" !== e.type)) {
                                const t = e.value;
                                (e.value = ""), (e.value = t);
                            }
                        },
                        K = (e, t, n) => {
                            e &&
                                t &&
                                ("string" == typeof t && (t = t.split(/\s+/).filter(Boolean)),
                                t.forEach((t) => {
                                    Array.isArray(e)
                                        ? e.forEach((e) => {
                                              n ? e.classList.add(t) : e.classList.remove(t);
                                          })
                                        : n
                                        ? e.classList.add(t)
                                        : e.classList.remove(t);
                                }));
                        },
                        X = (e, t) => {
                            K(e, t, !0);
                        },
                        J = (e, t) => {
                            K(e, t, !1);
                        },
                        G = (e, t) => {
                            const n = Array.from(e.children);
                            for (let e = 0; e < n.length; e++) {
                                const a = n[e];
                                if (a instanceof HTMLElement && F(a, t)) return a;
                            }
                        },
                        ee = (e, t, n) => {
                            n === `${parseInt(n)}` && (n = parseInt(n)), n || 0 === parseInt(n) ? (e.style[t] = "number" == typeof n ? `${n}px` : n) : e.style.removeProperty(t);
                        },
                        te = function (e) {
                            let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "flex";
                            e && (e.style.display = t);
                        },
                        ne = (e) => {
                            e && (e.style.display = "none");
                        },
                        ae = (e, t, n, a) => {
                            const o = e.querySelector(t);
                            o && (o.style[n] = a);
                        },
                        oe = function (e, t) {
                            t ? te(e, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "flex") : ne(e);
                        },
                        se = (e) => !(!e || !(e.offsetWidth || e.offsetHeight || e.getClientRects().length)),
                        re = () => !se(P()) && !se(D()) && !se(E()),
                        ie = (e) => !!(e.scrollHeight > e.clientHeight),
                        le = (e) => {
                            const t = window.getComputedStyle(e),
                                n = parseFloat(t.getPropertyValue("animation-duration") || "0"),
                                a = parseFloat(t.getPropertyValue("transition-duration") || "0");
                            return n > 0 || a > 0;
                        },
                        ce = function (e) {
                            let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                            const n = z();
                            se(n) &&
                                (t && ((n.style.transition = "none"), (n.style.width = "100%")),
                                setTimeout(() => {
                                    (n.style.transition = `width ${e / 1e3}s linear`), (n.style.width = "0%");
                                }, 10));
                        },
                        de = () => {
                            const e = z(),
                                t = parseInt(window.getComputedStyle(e).width);
                            e.style.removeProperty("transition"), (e.style.width = "100%");
                            const n = (t / parseInt(window.getComputedStyle(e).width)) * 100;
                            e.style.width = `${n}%`;
                        },
                        ue = () => "undefined" == typeof window || "undefined" == typeof document,
                        pe = `\n <div aria-labelledby="${r.title}" aria-describedby="${r["html-container"]}" class="${r.popup}" tabindex="-1">\n   <button type="button" class="${r.close}"></button>\n   <ul class="${r["progress-steps"]}"></ul>\n   <div class="${r.icon}"></div>\n   <img class="${r.image}" />\n   <h2 class="${r.title}" id="${r.title}"></h2>\n   <div class="${r["html-container"]}" id="${r["html-container"]}"></div>\n   <input class="${r.input}" id="${r.input}" />\n   <input type="file" class="${r.file}" />\n   <div class="${r.range}">\n     <input type="range" />\n     <output></output>\n   </div>\n   <select class="${r.select}" id="${r.select}"></select>\n   <div class="${r.radio}"></div>\n   <label class="${r.checkbox}">\n     <input type="checkbox" id="${r.checkbox}" />\n     <span class="${r.label}"></span>\n   </label>\n   <textarea class="${r.textarea}" id="${r.textarea}"></textarea>\n   <div class="${r["validation-message"]}" id="${r["validation-message"]}"></div>\n   <div class="${r.actions}">\n     <div class="${r.loader}"></div>\n     <button type="button" class="${r.confirm}"></button>\n     <button type="button" class="${r.deny}"></button>\n     <button type="button" class="${r.cancel}"></button>\n   </div>\n   <div class="${r.footer}"></div>\n   <div class="${r["timer-progress-bar-container"]}">\n     <div class="${r["timer-progress-bar"]}"></div>\n   </div>\n </div>\n`.replace(
                            /(^|\n)\s*/g,
                            ""
                        ),
                        me = () => {
                            const e = v();
                            return !!e && (e.remove(), J([document.documentElement, document.body], [r["no-backdrop"], r["toast-shown"], r["has-column"]]), !0);
                        },
                        we = () => {
                            t.currentInstance.resetValidationMessage();
                        },
                        he = () => {
                            const e = k(),
                                t = G(e, r.input),
                                n = G(e, r.file),
                                a = e.querySelector(`.${r.range} input`),
                                o = e.querySelector(`.${r.range} output`),
                                s = G(e, r.select),
                                i = e.querySelector(`.${r.checkbox} input`),
                                l = G(e, r.textarea);
                            (t.oninput = we),
                                (n.onchange = we),
                                (s.onchange = we),
                                (i.onchange = we),
                                (l.oninput = we),
                                (a.oninput = () => {
                                    we(), (o.value = a.value);
                                }),
                                (a.onchange = () => {
                                    we(), (o.value = a.value);
                                });
                        },
                        fe = (e) => ("string" == typeof e ? document.querySelector(e) : e),
                        ge = (e) => {
                            const t = k();
                            t.setAttribute("role", e.toast ? "alert" : "dialog"), t.setAttribute("aria-live", e.toast ? "polite" : "assertive"), e.toast || t.setAttribute("aria-modal", "true");
                        },
                        be = (e) => {
                            "rtl" === window.getComputedStyle(e).direction && X(v(), r.rtl);
                        },
                        ve = (e) => {
                            const t = me();
                            if (ue()) return void u("SweetAlert2 requires document to initialize");
                            const n = document.createElement("div");
                            (n.className = r.container), t && X(n, r["no-transition"]), V(n, pe);
                            const a = fe(e.target);
                            a.appendChild(n), ge(e), be(a), he();
                        },
                        ye = (e, t) => {
                            e instanceof HTMLElement ? t.appendChild(e) : "object" == typeof e ? xe(e, t) : e && V(t, e);
                        },
                        xe = (e, t) => {
                            e.jquery ? ke(t, e) : V(t, e.toString());
                        },
                        ke = (e, t) => {
                            if (((e.textContent = ""), 0 in t)) for (let n = 0; n in t; n++) e.appendChild(t[n].cloneNode(!0));
                            else e.appendChild(t.cloneNode(!0));
                        },
                        $e = (() => {
                            if (ue()) return !1;
                            const e = document.createElement("div"),
                                t = { WebkitAnimation: "webkitAnimationEnd", animation: "animationend" };
                            for (const n in t) if (Object.prototype.hasOwnProperty.call(t, n) && void 0 !== e.style[n]) return t[n];
                            return !1;
                        })(),
                        Ce = (e, t) => {
                            const n = M(),
                                a = O();
                            n && a && (t.showConfirmButton || t.showDenyButton || t.showCancelButton ? te(n) : ne(n), Q(n, t, "actions"), Ae(n, a, t), V(a, t.loaderHtml || ""), Q(a, t, "loader"));
                        };
                    function Ae(e, t, n) {
                        const a = P(),
                            o = D(),
                            s = E();
                        a &&
                            o &&
                            s &&
                            (je(a, "confirm", n),
                            je(o, "deny", n),
                            je(s, "cancel", n),
                            Se(a, o, s, n),
                            n.reverseButtons && (n.toast ? (e.insertBefore(s, a), e.insertBefore(o, a)) : (e.insertBefore(s, t), e.insertBefore(o, t), e.insertBefore(a, t))));
                    }
                    function Se(e, t, n, a) {
                        a.buttonsStyling
                            ? (X([e, t, n], r.styled),
                              a.confirmButtonColor && ((e.style.backgroundColor = a.confirmButtonColor), X(e, r["default-outline"])),
                              a.denyButtonColor && ((t.style.backgroundColor = a.denyButtonColor), X(t, r["default-outline"])),
                              a.cancelButtonColor && ((n.style.backgroundColor = a.cancelButtonColor), X(n, r["default-outline"])))
                            : J([e, t, n], r.styled);
                    }
                    function je(e, t, n) {
                        const a = c(t);
                        oe(e, n[`show${a}Button`], "inline-block"), V(e, n[`${t}ButtonText`] || ""), e.setAttribute("aria-label", n[`${t}ButtonAriaLabel`] || ""), (e.className = r[t]), Q(e, n, `${t}Button`);
                    }
                    const Te = (e, t) => {
                            const n = q();
                            n && (V(n, t.closeButtonHtml || ""), Q(n, t, "closeButton"), oe(n, t.showCloseButton), n.setAttribute("aria-label", t.closeButtonAriaLabel || ""));
                        },
                        Be = (e, t) => {
                            const n = v();
                            n && (Pe(n, t.backdrop), Ee(n, t.position), De(n, t.grow), Q(n, t, "container"));
                        };
                    function Pe(e, t) {
                        "string" == typeof t ? (e.style.background = t) : t || X([document.documentElement, document.body], r["no-backdrop"]);
                    }
                    function Ee(e, t) {
                        t && (t in r ? X(e, r[t]) : (d('The "position" parameter is not valid, defaulting to "center"'), X(e, r.center)));
                    }
                    function De(e, t) {
                        t && X(e, r[`grow-${t}`]);
                    }
                    const Le = ["input", "file", "range", "select", "radio", "checkbox", "textarea"],
                        Oe = (e, t) => {
                            const n = k(),
                                a = o.innerParams.get(e),
                                s = !a || t.input !== a.input;
                            Le.forEach((e) => {
                                const a = G(n, r[e]);
                                ze(e, t.inputAttributes), (a.className = r[e]), s && ne(a);
                            }),
                                t.input && (s && Me(t), qe(t));
                        },
                        Me = (e) => {
                            if (!Ne[e.input]) return void u(`Unexpected type of input! Expected "text", "email", "password", "number", "tel", "select", "radio", "checkbox", "textarea", "file" or "url", got "${e.input}"`);
                            const t = Ue(e.input),
                                n = Ne[e.input](t, e);
                            te(t),
                                e.inputAutoFocus &&
                                    setTimeout(() => {
                                        W(n);
                                    });
                        },
                        _e = (e) => {
                            for (let t = 0; t < e.attributes.length; t++) {
                                const n = e.attributes[t].name;
                                ["id", "type", "value", "style"].includes(n) || e.removeAttribute(n);
                            }
                        },
                        ze = (e, t) => {
                            const n = Y(k(), e);
                            if (n) {
                                _e(n);
                                for (const e in t) n.setAttribute(e, t[e]);
                            }
                        },
                        qe = (e) => {
                            const t = Ue(e.input);
                            "object" == typeof e.customClass && X(t, e.customClass.input);
                        },
                        He = (e, t) => {
                            (e.placeholder && !t.inputPlaceholder) || (e.placeholder = t.inputPlaceholder);
                        },
                        Ie = (e, t, n) => {
                            if (n.inputLabel) {
                                const a = document.createElement("label"),
                                    o = r["input-label"];
                                a.setAttribute("for", e.id), (a.className = o), "object" == typeof n.customClass && X(a, n.customClass.inputLabel), (a.innerText = n.inputLabel), t.insertAdjacentElement("beforebegin", a);
                            }
                        },
                        Ue = (e) => G(k(), r[e] || r.input),
                        Re = (e, t) => {
                            ["string", "number"].includes(typeof t) ? (e.value = `${t}`) : b(t) || d(`Unexpected type of inputValue! Expected "string", "number" or "Promise", got "${typeof t}"`);
                        },
                        Ne = {};
                    (Ne.text = Ne.email = Ne.password = Ne.number = Ne.tel = Ne.url = (e, t) => (Re(e, t.inputValue), Ie(e, e, t), He(e, t), (e.type = t.input), e)),
                        (Ne.file = (e, t) => (Ie(e, e, t), He(e, t), e)),
                        (Ne.range = (e, t) => {
                            const n = e.querySelector("input"),
                                a = e.querySelector("output");
                            return Re(n, t.inputValue), (n.type = t.input), Re(a, t.inputValue), Ie(n, e, t), e;
                        }),
                        (Ne.select = (e, t) => {
                            if (((e.textContent = ""), t.inputPlaceholder)) {
                                const n = document.createElement("option");
                                V(n, t.inputPlaceholder), (n.value = ""), (n.disabled = !0), (n.selected = !0), e.appendChild(n);
                            }
                            return Ie(e, e, t), e;
                        }),
                        (Ne.radio = (e) => ((e.textContent = ""), e)),
                        (Ne.checkbox = (e, t) => {
                            const n = Y(k(), "checkbox");
                            (n.value = "1"), (n.checked = Boolean(t.inputValue));
                            const a = e.querySelector("span");
                            return V(a, t.inputPlaceholder), n;
                        }),
                        (Ne.textarea = (e, t) => {
                            Re(e, t.inputValue), He(e, t), Ie(e, e, t);
                            const n = (e) => parseInt(window.getComputedStyle(e).marginLeft) + parseInt(window.getComputedStyle(e).marginRight);
                            return (
                                setTimeout(() => {
                                    if ("MutationObserver" in window) {
                                        const a = parseInt(window.getComputedStyle(k()).width);
                                        new MutationObserver(() => {
                                            if (!document.body.contains(e)) return;
                                            const o = e.offsetWidth + n(e);
                                            o > a ? (k().style.width = `${o}px`) : ee(k(), "width", t.width);
                                        }).observe(e, { attributes: !0, attributeFilter: ["style"] });
                                    }
                                }),
                                e
                            );
                        });
                    const Ve = (e, t) => {
                            const n = S();
                            n && (Q(n, t, "htmlContainer"), t.html ? (ye(t.html, n), te(n, "block")) : t.text ? ((n.textContent = t.text), te(n, "block")) : ne(n), Oe(e, t));
                        },
                        Fe = (e, t) => {
                            const n = _();
                            n && (oe(n, t.footer), t.footer && ye(t.footer, n), Q(n, t, "footer"));
                        },
                        Ze = (e, t) => {
                            const n = o.innerParams.get(e),
                                a = $();
                            if (a) {
                                if (n && t.icon === n.icon) return Xe(a, t), void Qe(a, t);
                                if (t.icon || t.iconHtml) {
                                    if (t.icon && -1 === Object.keys(i).indexOf(t.icon)) return u(`Unknown icon! Expected "success", "error", "warning", "info" or "question", got "${t.icon}"`), void ne(a);
                                    te(a), Xe(a, t), Qe(a, t), X(a, t.showClass && t.showClass.icon);
                                } else ne(a);
                            }
                        },
                        Qe = (e, t) => {
                            for (const [n, a] of Object.entries(i)) t.icon !== n && J(e, a);
                            X(e, t.icon && i[t.icon]), Je(e, t), Ye(), Q(e, t, "icon");
                        },
                        Ye = () => {
                            const e = k();
                            if (!e) return;
                            const t = window.getComputedStyle(e).getPropertyValue("background-color"),
                                n = e.querySelectorAll("[class^=swal2-success-circular-line], .swal2-success-fix");
                            for (let e = 0; e < n.length; e++) n[e].style.backgroundColor = t;
                        },
                        We =
                            '\n  <div class="swal2-success-circular-line-left"></div>\n  <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>\n  <div class="swal2-success-ring"></div> <div class="swal2-success-fix"></div>\n  <div class="swal2-success-circular-line-right"></div>\n',
                        Ke = '\n  <span class="swal2-x-mark">\n    <span class="swal2-x-mark-line-left"></span>\n    <span class="swal2-x-mark-line-right"></span>\n  </span>\n',
                        Xe = (e, t) => {
                            if (!t.icon && !t.iconHtml) return;
                            let n = e.innerHTML,
                                a = "";
                            t.iconHtml
                                ? (a = Ge(t.iconHtml))
                                : "success" === t.icon
                                ? ((a = We), (n = n.replace(/ style=".*?"/g, "")))
                                : "error" === t.icon
                                ? (a = Ke)
                                : t.icon && (a = Ge({ question: "?", warning: "!", info: "i" }[t.icon])),
                                n.trim() !== a.trim() && V(e, a);
                        },
                        Je = (e, t) => {
                            if (t.iconColor) {
                                (e.style.color = t.iconColor), (e.style.borderColor = t.iconColor);
                                for (const n of [".swal2-success-line-tip", ".swal2-success-line-long", ".swal2-x-mark-line-left", ".swal2-x-mark-line-right"]) ae(e, n, "backgroundColor", t.iconColor);
                                ae(e, ".swal2-success-ring", "borderColor", t.iconColor);
                            }
                        },
                        Ge = (e) => `<div class="${r["icon-content"]}">${e}</div>`,
                        et = (e, t) => {
                            const n = j();
                            n &&
                                (t.imageUrl
                                    ? (te(n, ""), n.setAttribute("src", t.imageUrl), n.setAttribute("alt", t.imageAlt || ""), ee(n, "width", t.imageWidth), ee(n, "height", t.imageHeight), (n.className = r.image), Q(n, t, "image"))
                                    : ne(n));
                        },
                        tt = (e, t) => {
                            const n = v(),
                                a = k();
                            if (n && a) {
                                if (t.toast) {
                                    ee(n, "width", t.width), (a.style.width = "100%");
                                    const e = O();
                                    e && a.insertBefore(e, $());
                                } else ee(a, "width", t.width);
                                ee(a, "padding", t.padding), t.color && (a.style.color = t.color), t.background && (a.style.background = t.background), ne(B()), nt(a, t);
                            }
                        },
                        nt = (e, t) => {
                            const n = t.showClass || {};
                            (e.className = `${r.popup} ${se(e) ? n.popup : ""}`),
                                t.toast ? (X([document.documentElement, document.body], r["toast-shown"]), X(e, r.toast)) : X(e, r.modal),
                                Q(e, t, "popup"),
                                "string" == typeof t.customClass && X(e, t.customClass),
                                t.icon && X(e, r[`icon-${t.icon}`]);
                        },
                        at = (e, t) => {
                            const n = T();
                            if (!n) return;
                            const { progressSteps: a, currentProgressStep: o } = t;
                            a && 0 !== a.length && void 0 !== o
                                ? (te(n),
                                  (n.textContent = ""),
                                  o >= a.length && d("Invalid currentProgressStep parameter, it should be less than progressSteps.length (currentProgressStep like JS arrays starts from 0)"),
                                  a.forEach((e, s) => {
                                      const i = ot(e);
                                      if ((n.appendChild(i), s === o && X(i, r["active-progress-step"]), s !== a.length - 1)) {
                                          const e = st(t);
                                          n.appendChild(e);
                                      }
                                  }))
                                : ne(n);
                        },
                        ot = (e) => {
                            const t = document.createElement("li");
                            return X(t, r["progress-step"]), V(t, e), t;
                        },
                        st = (e) => {
                            const t = document.createElement("li");
                            return X(t, r["progress-step-line"]), e.progressStepsDistance && ee(t, "width", e.progressStepsDistance), t;
                        },
                        rt = (e, t) => {
                            const n = A();
                            n && (oe(n, t.title || t.titleText, "block"), t.title && ye(t.title, n), t.titleText && (n.innerText = t.titleText), Q(n, t, "title"));
                        },
                        it = (e, t) => {
                            tt(e, t), Be(e, t), at(e, t), Ze(e, t), et(e, t), rt(e, t), Te(e, t), Ve(e, t), Ce(e, t), Fe(e, t);
                            const n = k();
                            "function" == typeof t.didRender && n && t.didRender(n);
                        },
                        lt = () => se(k()),
                        ct = () => P() && P().click(),
                        dt = () => D() && D().click(),
                        ut = () => E() && E().click(),
                        pt = Object.freeze({ cancel: "cancel", backdrop: "backdrop", close: "close", esc: "esc", timer: "timer" }),
                        mt = (e) => {
                            e.keydownTarget && e.keydownHandlerAdded && (e.keydownTarget.removeEventListener("keydown", e.keydownHandler, { capture: e.keydownListenerCapture }), (e.keydownHandlerAdded = !1));
                        },
                        wt = (e, t, n, a) => {
                            mt(t),
                                n.toast ||
                                    ((t.keydownHandler = (t) => bt(e, t, a)),
                                    (t.keydownTarget = n.keydownListenerCapture ? window : k()),
                                    (t.keydownListenerCapture = n.keydownListenerCapture),
                                    t.keydownTarget.addEventListener("keydown", t.keydownHandler, { capture: t.keydownListenerCapture }),
                                    (t.keydownHandlerAdded = !0));
                        },
                        ht = (e, t) => {
                            const n = I();
                            if (n.length) return (e += t) === n.length ? (e = 0) : -1 === e && (e = n.length - 1), void n[e].focus();
                            k().focus();
                        },
                        ft = ["ArrowRight", "ArrowDown"],
                        gt = ["ArrowLeft", "ArrowUp"],
                        bt = (e, t, n) => {
                            const a = o.innerParams.get(e);
                            a &&
                                (t.isComposing ||
                                    229 === t.keyCode ||
                                    (a.stopKeydownPropagation && t.stopPropagation(), "Enter" === t.key ? vt(e, t, a) : "Tab" === t.key ? yt(t) : [...ft, ...gt].includes(t.key) ? xt(t.key) : "Escape" === t.key && kt(t, a, n)));
                        },
                        vt = (e, t, n) => {
                            if (h(n.allowEnterKey) && t.target && e.getInput() && t.target instanceof HTMLElement && t.target.outerHTML === e.getInput().outerHTML) {
                                if (["textarea", "file"].includes(n.input)) return;
                                ct(), t.preventDefault();
                            }
                        },
                        yt = (e) => {
                            const t = e.target,
                                n = I();
                            let a = -1;
                            for (let e = 0; e < n.length; e++)
                                if (t === n[e]) {
                                    a = e;
                                    break;
                                }
                            e.shiftKey ? ht(a, -1) : ht(a, 1), e.stopPropagation(), e.preventDefault();
                        },
                        xt = (e) => {
                            const t = [P(), D(), E()];
                            if (document.activeElement instanceof HTMLElement && !t.includes(document.activeElement)) return;
                            const n = ft.includes(e) ? "nextElementSibling" : "previousElementSibling";
                            let a = document.activeElement;
                            for (let e = 0; e < M().children.length; e++) {
                                if (((a = a[n]), !a)) return;
                                if (a instanceof HTMLButtonElement && se(a)) break;
                            }
                            a instanceof HTMLButtonElement && a.focus();
                        },
                        kt = (e, t, n) => {
                            h(t.allowEscapeKey) && (e.preventDefault(), n(pt.esc));
                        };
                    var $t = { swalPromiseResolve: new WeakMap(), swalPromiseReject: new WeakMap() };
                    const Ct = () => {
                            Array.from(document.body.children).forEach((e) => {
                                e === v() || e.contains(v()) || (e.hasAttribute("aria-hidden") && e.setAttribute("data-previous-aria-hidden", e.getAttribute("aria-hidden") || ""), e.setAttribute("aria-hidden", "true"));
                            });
                        },
                        At = () => {
                            Array.from(document.body.children).forEach((e) => {
                                e.hasAttribute("data-previous-aria-hidden")
                                    ? (e.setAttribute("aria-hidden", e.getAttribute("data-previous-aria-hidden") || ""), e.removeAttribute("data-previous-aria-hidden"))
                                    : e.removeAttribute("aria-hidden");
                            });
                        },
                        St = "undefined" != typeof window && !!window.GestureEvent,
                        jt = () => {
                            if (St && !F(document.body, r.iosfix)) {
                                const e = document.body.scrollTop;
                                (document.body.style.top = -1 * e + "px"), X(document.body, r.iosfix), Tt();
                            }
                        },
                        Tt = () => {
                            const e = v();
                            let t;
                            (e.ontouchstart = (e) => {
                                t = Bt(e);
                            }),
                                (e.ontouchmove = (e) => {
                                    t && (e.preventDefault(), e.stopPropagation());
                                });
                        },
                        Bt = (e) => {
                            const t = e.target,
                                n = v();
                            return !(Pt(e) || Et(e) || (t !== n && (ie(n) || !(t instanceof HTMLElement) || "INPUT" === t.tagName || "TEXTAREA" === t.tagName || (ie(S()) && S().contains(t)))));
                        },
                        Pt = (e) => e.touches && e.touches.length && "stylus" === e.touches[0].touchType,
                        Et = (e) => e.touches && e.touches.length > 1,
                        Dt = () => {
                            if (F(document.body, r.iosfix)) {
                                const e = parseInt(document.body.style.top, 10);
                                J(document.body, r.iosfix), (document.body.style.top = ""), (document.body.scrollTop = -1 * e);
                            }
                        },
                        Lt = () => {
                            const e = document.createElement("div");
                            (e.className = r["scrollbar-measure"]), document.body.appendChild(e);
                            const t = e.getBoundingClientRect().width - e.clientWidth;
                            return document.body.removeChild(e), t;
                        };
                    let Ot = null;
                    const Mt = () => {
                            null === Ot &&
                                document.body.scrollHeight > window.innerHeight &&
                                ((Ot = parseInt(window.getComputedStyle(document.body).getPropertyValue("padding-right"))), (document.body.style.paddingRight = `${Ot + Lt()}px`));
                        },
                        _t = () => {
                            null !== Ot && ((document.body.style.paddingRight = `${Ot}px`), (Ot = null));
                        };
                    function zt(e, n, o, s) {
                        R() ? Zt(e, s) : (a(o).then(() => Zt(e, s)), mt(t)), St ? (n.setAttribute("style", "display:none !important"), n.removeAttribute("class"), (n.innerHTML = "")) : n.remove(), U() && (_t(), Dt(), At()), qt();
                    }
                    function qt() {
                        J([document.documentElement, document.body], [r.shown, r["height-auto"], r["no-backdrop"], r["toast-shown"]]);
                    }
                    function Ht(e) {
                        e = Nt(e);
                        const t = $t.swalPromiseResolve.get(this),
                            n = It(this);
                        this.isAwaitingPromise ? e.isDismissed || (Rt(this), t(e)) : n && t(e);
                    }
                    const It = (e) => {
                        const t = k();
                        if (!t) return !1;
                        const n = o.innerParams.get(e);
                        if (!n || F(t, n.hideClass.popup)) return !1;
                        J(t, n.showClass.popup), X(t, n.hideClass.popup);
                        const a = v();
                        return J(a, n.showClass.backdrop), X(a, n.hideClass.backdrop), Vt(e, t, n), !0;
                    };
                    function Ut(e) {
                        const t = $t.swalPromiseReject.get(this);
                        Rt(this), t && t(e);
                    }
                    const Rt = (e) => {
                            e.isAwaitingPromise && (delete e.isAwaitingPromise, o.innerParams.get(e) || e._destroy());
                        },
                        Nt = (e) => (void 0 === e ? { isConfirmed: !1, isDenied: !1, isDismissed: !0 } : Object.assign({ isConfirmed: !1, isDenied: !1, isDismissed: !1 }, e)),
                        Vt = (e, t, n) => {
                            const a = v(),
                                o = $e && le(t);
                            "function" == typeof n.willClose && n.willClose(t), o ? Ft(e, t, a, n.returnFocus, n.didClose) : zt(e, a, n.returnFocus, n.didClose);
                        },
                        Ft = (e, n, a, o, s) => {
                            (t.swalCloseEventFinishedCallback = zt.bind(null, e, a, o, s)),
                                n.addEventListener($e, function (e) {
                                    e.target === n && (t.swalCloseEventFinishedCallback(), delete t.swalCloseEventFinishedCallback);
                                });
                        },
                        Zt = (e, t) => {
                            setTimeout(() => {
                                "function" == typeof t && t.bind(e.params)(), e._destroy && e._destroy();
                            });
                        },
                        Qt = (e) => {
                            let t = k();
                            t || new Va(), (t = k());
                            const n = O();
                            R() ? ne($()) : Yt(t, e), te(n), t.setAttribute("data-loading", "true"), t.setAttribute("aria-busy", "true"), t.focus();
                        },
                        Yt = (e, t) => {
                            const n = M(),
                                a = O();
                            !t && se(P()) && (t = P()), te(n), t && (ne(t), a.setAttribute("data-button-to-replace", t.className)), a.parentNode.insertBefore(a, t), X([e, n], r.loading);
                        },
                        Wt = (e, t) => {
                            "select" === t.input || "radio" === t.input ? en(e, t) : ["text", "email", "number", "tel", "textarea"].includes(t.input) && (f(t.inputValue) || b(t.inputValue)) && (Qt(P()), tn(e, t));
                        },
                        Kt = (e, t) => {
                            const n = e.getInput();
                            if (!n) return null;
                            switch (t.input) {
                                case "checkbox":
                                    return Xt(n);
                                case "radio":
                                    return Jt(n);
                                case "file":
                                    return Gt(n);
                                default:
                                    return t.inputAutoTrim ? n.value.trim() : n.value;
                            }
                        },
                        Xt = (e) => (e.checked ? 1 : 0),
                        Jt = (e) => (e.checked ? e.value : null),
                        Gt = (e) => (e.files.length ? (null !== e.getAttribute("multiple") ? e.files : e.files[0]) : null),
                        en = (e, t) => {
                            const n = k(),
                                a = (e) => {
                                    nn[t.input](n, an(e), t);
                                };
                            f(t.inputOptions) || b(t.inputOptions)
                                ? (Qt(P()),
                                  g(t.inputOptions).then((t) => {
                                      e.hideLoading(), a(t);
                                  }))
                                : "object" == typeof t.inputOptions
                                ? a(t.inputOptions)
                                : u("Unexpected type of inputOptions! Expected object, Map or Promise, got " + typeof t.inputOptions);
                        },
                        tn = (e, t) => {
                            const n = e.getInput();
                            ne(n),
                                g(t.inputValue)
                                    .then((a) => {
                                        (n.value = "number" === t.input ? `${parseFloat(a) || 0}` : `${a}`), te(n), n.focus(), e.hideLoading();
                                    })
                                    .catch((t) => {
                                        u(`Error in inputValue promise: ${t}`), (n.value = ""), te(n), n.focus(), e.hideLoading();
                                    });
                        },
                        nn = {
                            select: (e, t, n) => {
                                const a = G(e, r.select),
                                    o = (e, t, a) => {
                                        const o = document.createElement("option");
                                        (o.value = a), V(o, t), (o.selected = on(a, n.inputValue)), e.appendChild(o);
                                    };
                                t.forEach((e) => {
                                    const t = e[0],
                                        n = e[1];
                                    if (Array.isArray(n)) {
                                        const e = document.createElement("optgroup");
                                        (e.label = t), (e.disabled = !1), a.appendChild(e), n.forEach((t) => o(e, t[1], t[0]));
                                    } else o(a, n, t);
                                }),
                                    a.focus();
                            },
                            radio: (e, t, n) => {
                                const a = G(e, r.radio);
                                t.forEach((e) => {
                                    const t = e[0],
                                        o = e[1],
                                        s = document.createElement("input"),
                                        i = document.createElement("label");
                                    (s.type = "radio"), (s.name = r.radio), (s.value = t), on(t, n.inputValue) && (s.checked = !0);
                                    const l = document.createElement("span");
                                    V(l, o), (l.className = r.label), i.appendChild(s), i.appendChild(l), a.appendChild(i);
                                });
                                const o = a.querySelectorAll("input");
                                o.length && o[0].focus();
                            },
                        },
                        an = (e) => {
                            const t = [];
                            return (
                                "undefined" != typeof Map && e instanceof Map
                                    ? e.forEach((e, n) => {
                                          let a = e;
                                          "object" == typeof a && (a = an(a)), t.push([n, a]);
                                      })
                                    : Object.keys(e).forEach((n) => {
                                          let a = e[n];
                                          "object" == typeof a && (a = an(a)), t.push([n, a]);
                                      }),
                                t
                            );
                        },
                        on = (e, t) => t && t.toString() === e.toString(),
                        sn = (e) => {
                            const t = o.innerParams.get(e);
                            e.disableButtons(), t.input ? cn(e, "confirm") : wn(e, !0);
                        },
                        rn = (e) => {
                            const t = o.innerParams.get(e);
                            e.disableButtons(), t.returnInputValueOnDeny ? cn(e, "deny") : un(e, !1);
                        },
                        ln = (e, t) => {
                            e.disableButtons(), t(pt.cancel);
                        },
                        cn = (e, t) => {
                            const n = o.innerParams.get(e);
                            if (!n.input) return void u(`The "input" parameter is needed to be set when using returnInputValueOn${c(t)}`);
                            const a = Kt(e, n);
                            n.inputValidator ? dn(e, a, t) : e.getInput().checkValidity() ? ("deny" === t ? un(e, a) : wn(e, a)) : (e.enableButtons(), e.showValidationMessage(n.validationMessage));
                        },
                        dn = (e, t, n) => {
                            const a = o.innerParams.get(e);
                            e.disableInput(),
                                Promise.resolve()
                                    .then(() => g(a.inputValidator(t, a.validationMessage)))
                                    .then((a) => {
                                        e.enableButtons(), e.enableInput(), a ? e.showValidationMessage(a) : "deny" === n ? un(e, t) : wn(e, t);
                                    });
                        },
                        un = (e, t) => {
                            const n = o.innerParams.get(e || void 0);
                            n.showLoaderOnDeny && Qt(D()),
                                n.preDeny
                                    ? ((e.isAwaitingPromise = !0),
                                      Promise.resolve()
                                          .then(() => g(n.preDeny(t, n.validationMessage)))
                                          .then((n) => {
                                              !1 === n ? (e.hideLoading(), Rt(e)) : e.close({ isDenied: !0, value: void 0 === n ? t : n });
                                          })
                                          .catch((t) => mn(e || void 0, t)))
                                    : e.close({ isDenied: !0, value: t });
                        },
                        pn = (e, t) => {
                            e.close({ isConfirmed: !0, value: t });
                        },
                        mn = (e, t) => {
                            e.rejectPromise(t);
                        },
                        wn = (e, t) => {
                            const n = o.innerParams.get(e || void 0);
                            n.showLoaderOnConfirm && Qt(),
                                n.preConfirm
                                    ? (e.resetValidationMessage(),
                                      (e.isAwaitingPromise = !0),
                                      Promise.resolve()
                                          .then(() => g(n.preConfirm(t, n.validationMessage)))
                                          .then((n) => {
                                              se(B()) || !1 === n ? (e.hideLoading(), Rt(e)) : pn(e, void 0 === n ? t : n);
                                          })
                                          .catch((t) => mn(e || void 0, t)))
                                    : pn(e, t);
                        };
                    function hn() {
                        const e = o.innerParams.get(this);
                        if (!e) return;
                        const t = o.domCache.get(this);
                        ne(t.loader),
                            R() ? e.icon && te($()) : fn(t),
                            J([t.popup, t.actions], r.loading),
                            t.popup.removeAttribute("aria-busy"),
                            t.popup.removeAttribute("data-loading"),
                            (t.confirmButton.disabled = !1),
                            (t.denyButton.disabled = !1),
                            (t.cancelButton.disabled = !1);
                    }
                    const fn = (e) => {
                        const t = e.popup.getElementsByClassName(e.loader.getAttribute("data-button-to-replace"));
                        t.length ? te(t[0], "inline-block") : re() && ne(e.actions);
                    };
                    function gn() {
                        const e = o.innerParams.get(this),
                            t = o.domCache.get(this);
                        return t ? Y(t.popup, e.input) : null;
                    }
                    function bn(e, t, n) {
                        const a = o.domCache.get(e);
                        t.forEach((e) => {
                            a[e].disabled = n;
                        });
                    }
                    function vn(e, t) {
                        if (e)
                            if ("radio" === e.type) {
                                const n = e.parentNode.parentNode.querySelectorAll("input");
                                for (let e = 0; e < n.length; e++) n[e].disabled = t;
                            } else e.disabled = t;
                    }
                    function yn() {
                        bn(this, ["confirmButton", "denyButton", "cancelButton"], !1);
                    }
                    function xn() {
                        bn(this, ["confirmButton", "denyButton", "cancelButton"], !0);
                    }
                    function kn() {
                        vn(this.getInput(), !1);
                    }
                    function $n() {
                        vn(this.getInput(), !0);
                    }
                    function Cn(e) {
                        const t = o.domCache.get(this),
                            n = o.innerParams.get(this);
                        V(t.validationMessage, e),
                            (t.validationMessage.className = r["validation-message"]),
                            n.customClass && n.customClass.validationMessage && X(t.validationMessage, n.customClass.validationMessage),
                            te(t.validationMessage);
                        const a = this.getInput();
                        a && (a.setAttribute("aria-invalid", !0), a.setAttribute("aria-describedby", r["validation-message"]), W(a), X(a, r.inputerror));
                    }
                    function An() {
                        const e = o.domCache.get(this);
                        e.validationMessage && ne(e.validationMessage);
                        const t = this.getInput();
                        t && (t.removeAttribute("aria-invalid"), t.removeAttribute("aria-describedby"), J(t, r.inputerror));
                    }
                    const Sn = {
                            title: "",
                            titleText: "",
                            text: "",
                            html: "",
                            footer: "",
                            icon: void 0,
                            iconColor: void 0,
                            iconHtml: void 0,
                            template: void 0,
                            toast: !1,
                            showClass: { popup: "swal2-show", backdrop: "swal2-backdrop-show", icon: "swal2-icon-show" },
                            hideClass: { popup: "swal2-hide", backdrop: "swal2-backdrop-hide", icon: "swal2-icon-hide" },
                            customClass: {},
                            target: "body",
                            color: void 0,
                            backdrop: !0,
                            heightAuto: !0,
                            allowOutsideClick: !0,
                            allowEscapeKey: !0,
                            allowEnterKey: !0,
                            stopKeydownPropagation: !0,
                            keydownListenerCapture: !1,
                            showConfirmButton: !0,
                            showDenyButton: !1,
                            showCancelButton: !1,
                            preConfirm: void 0,
                            preDeny: void 0,
                            confirmButtonText: "OK",
                            confirmButtonAriaLabel: "",
                            confirmButtonColor: void 0,
                            denyButtonText: "No",
                            denyButtonAriaLabel: "",
                            denyButtonColor: void 0,
                            cancelButtonText: "Cancel",
                            cancelButtonAriaLabel: "",
                            cancelButtonColor: void 0,
                            buttonsStyling: !0,
                            reverseButtons: !1,
                            focusConfirm: !0,
                            focusDeny: !1,
                            focusCancel: !1,
                            returnFocus: !0,
                            showCloseButton: !1,
                            closeButtonHtml: "&times;",
                            closeButtonAriaLabel: "Close this dialog",
                            loaderHtml: "",
                            showLoaderOnConfirm: !1,
                            showLoaderOnDeny: !1,
                            imageUrl: void 0,
                            imageWidth: void 0,
                            imageHeight: void 0,
                            imageAlt: "",
                            timer: void 0,
                            timerProgressBar: !1,
                            width: void 0,
                            padding: void 0,
                            background: void 0,
                            input: void 0,
                            inputPlaceholder: "",
                            inputLabel: "",
                            inputValue: "",
                            inputOptions: {},
                            inputAutoFocus: !0,
                            inputAutoTrim: !0,
                            inputAttributes: {},
                            inputValidator: void 0,
                            returnInputValueOnDeny: !1,
                            validationMessage: void 0,
                            grow: !1,
                            position: "center",
                            progressSteps: [],
                            currentProgressStep: void 0,
                            progressStepsDistance: void 0,
                            willOpen: void 0,
                            didOpen: void 0,
                            didRender: void 0,
                            willClose: void 0,
                            didClose: void 0,
                            didDestroy: void 0,
                            scrollbarPadding: !0,
                        },
                        jn = [
                            "allowEscapeKey",
                            "allowOutsideClick",
                            "background",
                            "buttonsStyling",
                            "cancelButtonAriaLabel",
                            "cancelButtonColor",
                            "cancelButtonText",
                            "closeButtonAriaLabel",
                            "closeButtonHtml",
                            "color",
                            "confirmButtonAriaLabel",
                            "confirmButtonColor",
                            "confirmButtonText",
                            "currentProgressStep",
                            "customClass",
                            "denyButtonAriaLabel",
                            "denyButtonColor",
                            "denyButtonText",
                            "didClose",
                            "didDestroy",
                            "footer",
                            "hideClass",
                            "html",
                            "icon",
                            "iconColor",
                            "iconHtml",
                            "imageAlt",
                            "imageHeight",
                            "imageUrl",
                            "imageWidth",
                            "preConfirm",
                            "preDeny",
                            "progressSteps",
                            "returnFocus",
                            "reverseButtons",
                            "showCancelButton",
                            "showCloseButton",
                            "showConfirmButton",
                            "showDenyButton",
                            "text",
                            "title",
                            "titleText",
                            "willClose",
                        ],
                        Tn = {},
                        Bn = ["allowOutsideClick", "allowEnterKey", "backdrop", "focusConfirm", "focusDeny", "focusCancel", "returnFocus", "heightAuto", "keydownListenerCapture"],
                        Pn = (e) => Object.prototype.hasOwnProperty.call(Sn, e),
                        En = (e) => -1 !== jn.indexOf(e),
                        Dn = (e) => Tn[e],
                        Ln = (e) => {
                            Pn(e) || d(`Unknown parameter "${e}"`);
                        },
                        On = (e) => {
                            Bn.includes(e) && d(`The parameter "${e}" is incompatible with toasts`);
                        },
                        Mn = (e) => {
                            const t = Dn(e);
                            t && w(e, t);
                        },
                        _n = (e) => {
                            !1 === e.backdrop && e.allowOutsideClick && d('"allowOutsideClick" parameter requires `backdrop` parameter to be set to `true`');
                            for (const t in e) Ln(t), e.toast && On(t), Mn(t);
                        };
                    function zn(e) {
                        const t = k(),
                            n = o.innerParams.get(this);
                        if (!t || F(t, n.hideClass.popup)) return void d("You're trying to update the closed or closing popup, that won't work. Use the update() method in preConfirm parameter or show a new popup.");
                        const a = qn(e),
                            s = Object.assign({}, n, a);
                        it(this, s), o.innerParams.set(this, s), Object.defineProperties(this, { params: { value: Object.assign({}, this.params, e), writable: !1, enumerable: !0 } });
                    }
                    const qn = (e) => {
                        const t = {};
                        return (
                            Object.keys(e).forEach((n) => {
                                En(n) ? (t[n] = e[n]) : d(`Invalid parameter to update: ${n}`);
                            }),
                            t
                        );
                    };
                    function Hn() {
                        const e = o.domCache.get(this),
                            n = o.innerParams.get(this);
                        n ? (e.popup && t.swalCloseEventFinishedCallback && (t.swalCloseEventFinishedCallback(), delete t.swalCloseEventFinishedCallback), "function" == typeof n.didDestroy && n.didDestroy(), In(this)) : Un(this);
                    }
                    const In = (e) => {
                            Un(e), delete e.params, delete t.keydownHandler, delete t.keydownTarget, delete t.currentInstance;
                        },
                        Un = (e) => {
                            e.isAwaitingPromise
                                ? (Rn(o, e), (e.isAwaitingPromise = !0))
                                : (Rn($t, e),
                                  Rn(o, e),
                                  delete e.isAwaitingPromise,
                                  delete e.disableButtons,
                                  delete e.enableButtons,
                                  delete e.getInput,
                                  delete e.disableInput,
                                  delete e.enableInput,
                                  delete e.hideLoading,
                                  delete e.disableLoading,
                                  delete e.showValidationMessage,
                                  delete e.resetValidationMessage,
                                  delete e.close,
                                  delete e.closePopup,
                                  delete e.closeModal,
                                  delete e.closeToast,
                                  delete e.rejectPromise,
                                  delete e.update,
                                  delete e._destroy);
                        },
                        Rn = (e, t) => {
                            for (const n in e) e[n].delete(t);
                        };
                    var Nn = Object.freeze({
                        __proto__: null,
                        _destroy: Hn,
                        close: Ht,
                        closeModal: Ht,
                        closePopup: Ht,
                        closeToast: Ht,
                        disableButtons: xn,
                        disableInput: $n,
                        disableLoading: hn,
                        enableButtons: yn,
                        enableInput: kn,
                        getInput: gn,
                        handleAwaitingPromise: Rt,
                        hideLoading: hn,
                        rejectPromise: Ut,
                        resetValidationMessage: An,
                        showValidationMessage: Cn,
                        update: zn,
                    });
                    const Vn = (e, t, n) => {
                            o.innerParams.get(e).toast ? Fn(e, t, n) : (Yn(t), Wn(t), Kn(e, t, n));
                        },
                        Fn = (e, t, n) => {
                            t.popup.onclick = () => {
                                const t = o.innerParams.get(e);
                                (t && (Zn(t) || t.timer || t.input)) || n(pt.close);
                            };
                        },
                        Zn = (e) => e.showConfirmButton || e.showDenyButton || e.showCancelButton || e.showCloseButton;
                    let Qn = !1;
                    const Yn = (e) => {
                            e.popup.onmousedown = () => {
                                e.container.onmouseup = function (t) {
                                    (e.container.onmouseup = void 0), t.target === e.container && (Qn = !0);
                                };
                            };
                        },
                        Wn = (e) => {
                            e.container.onmousedown = () => {
                                e.popup.onmouseup = function (t) {
                                    (e.popup.onmouseup = void 0), (t.target === e.popup || e.popup.contains(t.target)) && (Qn = !0);
                                };
                            };
                        },
                        Kn = (e, t, n) => {
                            t.container.onclick = (a) => {
                                const s = o.innerParams.get(e);
                                Qn ? (Qn = !1) : a.target === t.container && h(s.allowOutsideClick) && n(pt.backdrop);
                            };
                        },
                        Xn = (e) => "object" == typeof e && e.jquery,
                        Jn = (e) => e instanceof Element || Xn(e),
                        Gn = (e) => {
                            const t = {};
                            return (
                                "object" != typeof e[0] || Jn(e[0])
                                    ? ["title", "html", "icon"].forEach((n, a) => {
                                          const o = e[a];
                                          "string" == typeof o || Jn(o) ? (t[n] = o) : void 0 !== o && u(`Unexpected type of ${n}! Expected "string" or "Element", got ${typeof o}`);
                                      })
                                    : Object.assign(t, e[0]),
                                t
                            );
                        };
                    function ea() {
                        const e = this;
                        for (var t = arguments.length, n = new Array(t), a = 0; a < t; a++) n[a] = arguments[a];
                        return new e(...n);
                    }
                    function ta(e) {
                        class t extends this {
                            _main(t, n) {
                                return super._main(t, Object.assign({}, e, n));
                            }
                        }
                        return t;
                    }
                    const na = () => t.timeout && t.timeout.getTimerLeft(),
                        aa = () => {
                            if (t.timeout) return de(), t.timeout.stop();
                        },
                        oa = () => {
                            if (t.timeout) {
                                const e = t.timeout.start();
                                return ce(e), e;
                            }
                        },
                        sa = () => {
                            const e = t.timeout;
                            return e && (e.running ? aa() : oa());
                        },
                        ra = (e) => {
                            if (t.timeout) {
                                const n = t.timeout.increase(e);
                                return ce(n, !0), n;
                            }
                        },
                        ia = () => !(!t.timeout || !t.timeout.isRunning());
                    let la = !1;
                    const ca = {};
                    function da() {
                        (ca[arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "data-swal-template"] = this), la || (document.body.addEventListener("click", ua), (la = !0));
                    }
                    const ua = (e) => {
                        for (let t = e.target; t && t !== document; t = t.parentNode)
                            for (const e in ca) {
                                const n = t.getAttribute(e);
                                if (n) return void ca[e].fire({ template: n });
                            }
                    };
                    var pa = Object.freeze({
                        __proto__: null,
                        argsToParams: Gn,
                        bindClickHandler: da,
                        clickCancel: ut,
                        clickConfirm: ct,
                        clickDeny: dt,
                        enableLoading: Qt,
                        fire: ea,
                        getActions: M,
                        getCancelButton: E,
                        getCloseButton: q,
                        getConfirmButton: P,
                        getContainer: v,
                        getDenyButton: D,
                        getFocusableElements: I,
                        getFooter: _,
                        getHtmlContainer: S,
                        getIcon: $,
                        getIconContent: C,
                        getImage: j,
                        getInputLabel: L,
                        getLoader: O,
                        getPopup: k,
                        getProgressSteps: T,
                        getTimerLeft: na,
                        getTimerProgressBar: z,
                        getTitle: A,
                        getValidationMessage: B,
                        increaseTimer: ra,
                        isDeprecatedParameter: Dn,
                        isLoading: N,
                        isTimerRunning: ia,
                        isUpdatableParameter: En,
                        isValidParameter: Pn,
                        isVisible: lt,
                        mixin: ta,
                        resumeTimer: oa,
                        showLoading: Qt,
                        stopTimer: aa,
                        toggleTimer: sa,
                    });
                    class ma {
                        constructor(e, t) {
                            (this.callback = e), (this.remaining = t), (this.running = !1), this.start();
                        }
                        start() {
                            return this.running || ((this.running = !0), (this.started = new Date()), (this.id = setTimeout(this.callback, this.remaining))), this.remaining;
                        }
                        stop() {
                            return this.started && this.running && ((this.running = !1), clearTimeout(this.id), (this.remaining -= new Date().getTime() - this.started.getTime())), this.remaining;
                        }
                        increase(e) {
                            const t = this.running;
                            return t && this.stop(), (this.remaining += e), t && this.start(), this.remaining;
                        }
                        getTimerLeft() {
                            return this.running && (this.stop(), this.start()), this.remaining;
                        }
                        isRunning() {
                            return this.running;
                        }
                    }
                    const wa = ["swal-title", "swal-html", "swal-footer"],
                        ha = (e) => {
                            const t = "string" == typeof e.template ? document.querySelector(e.template) : e.template;
                            if (!t) return {};
                            const n = t.content;
                            return $a(n), Object.assign(fa(n), ga(n), ba(n), va(n), ya(n), xa(n), ka(n, wa));
                        },
                        fa = (e) => {
                            const t = {};
                            return (
                                Array.from(e.querySelectorAll("swal-param")).forEach((e) => {
                                    Ca(e, ["name", "value"]);
                                    const n = e.getAttribute("name"),
                                        a = e.getAttribute("value");
                                    "boolean" == typeof Sn[n] ? (t[n] = "false" !== a) : "object" == typeof Sn[n] ? (t[n] = JSON.parse(a)) : (t[n] = a);
                                }),
                                t
                            );
                        },
                        ga = (e) => {
                            const t = {};
                            return (
                                Array.from(e.querySelectorAll("swal-function-param")).forEach((e) => {
                                    const n = e.getAttribute("name"),
                                        a = e.getAttribute("value");
                                    t[n] = new Function(`return ${a}`)();
                                }),
                                t
                            );
                        },
                        ba = (e) => {
                            const t = {};
                            return (
                                Array.from(e.querySelectorAll("swal-button")).forEach((e) => {
                                    Ca(e, ["type", "color", "aria-label"]);
                                    const n = e.getAttribute("type");
                                    (t[`${n}ButtonText`] = e.innerHTML),
                                        (t[`show${c(n)}Button`] = !0),
                                        e.hasAttribute("color") && (t[`${n}ButtonColor`] = e.getAttribute("color")),
                                        e.hasAttribute("aria-label") && (t[`${n}ButtonAriaLabel`] = e.getAttribute("aria-label"));
                                }),
                                t
                            );
                        },
                        va = (e) => {
                            const t = {},
                                n = e.querySelector("swal-image");
                            return (
                                n &&
                                    (Ca(n, ["src", "width", "height", "alt"]),
                                    n.hasAttribute("src") && (t.imageUrl = n.getAttribute("src")),
                                    n.hasAttribute("width") && (t.imageWidth = n.getAttribute("width")),
                                    n.hasAttribute("height") && (t.imageHeight = n.getAttribute("height")),
                                    n.hasAttribute("alt") && (t.imageAlt = n.getAttribute("alt"))),
                                t
                            );
                        },
                        ya = (e) => {
                            const t = {},
                                n = e.querySelector("swal-icon");
                            return n && (Ca(n, ["type", "color"]), n.hasAttribute("type") && (t.icon = n.getAttribute("type")), n.hasAttribute("color") && (t.iconColor = n.getAttribute("color")), (t.iconHtml = n.innerHTML)), t;
                        },
                        xa = (e) => {
                            const t = {},
                                n = e.querySelector("swal-input");
                            n &&
                                (Ca(n, ["type", "label", "placeholder", "value"]),
                                (t.input = n.getAttribute("type") || "text"),
                                n.hasAttribute("label") && (t.inputLabel = n.getAttribute("label")),
                                n.hasAttribute("placeholder") && (t.inputPlaceholder = n.getAttribute("placeholder")),
                                n.hasAttribute("value") && (t.inputValue = n.getAttribute("value")));
                            const a = Array.from(e.querySelectorAll("swal-input-option"));
                            return (
                                a.length &&
                                    ((t.inputOptions = {}),
                                    a.forEach((e) => {
                                        Ca(e, ["value"]);
                                        const n = e.getAttribute("value"),
                                            a = e.innerHTML;
                                        t.inputOptions[n] = a;
                                    })),
                                t
                            );
                        },
                        ka = (e, t) => {
                            const n = {};
                            for (const a in t) {
                                const o = t[a],
                                    s = e.querySelector(o);
                                s && (Ca(s, []), (n[o.replace(/^swal-/, "")] = s.innerHTML.trim()));
                            }
                            return n;
                        },
                        $a = (e) => {
                            const t = wa.concat(["swal-param", "swal-function-param", "swal-button", "swal-image", "swal-icon", "swal-input", "swal-input-option"]);
                            Array.from(e.children).forEach((e) => {
                                const n = e.tagName.toLowerCase();
                                t.includes(n) || d(`Unrecognized element <${n}>`);
                            });
                        },
                        Ca = (e, t) => {
                            Array.from(e.attributes).forEach((n) => {
                                -1 === t.indexOf(n.name) && d([`Unrecognized attribute "${n.name}" on <${e.tagName.toLowerCase()}>.`, t.length ? `Allowed attributes are: ${t.join(", ")}` : "To set the value, use HTML within the element."]);
                            });
                        },
                        Aa = 10,
                        Sa = (e) => {
                            const n = v(),
                                a = k();
                            "function" == typeof e.willOpen && e.willOpen(a);
                            const o = window.getComputedStyle(document.body).overflowY;
                            Pa(n, a, e),
                                setTimeout(() => {
                                    Ta(n, a);
                                }, Aa),
                                U() && (Ba(n, e.scrollbarPadding, o), Ct()),
                                R() || t.previousActiveElement || (t.previousActiveElement = document.activeElement),
                                "function" == typeof e.didOpen && setTimeout(() => e.didOpen(a)),
                                J(n, r["no-transition"]);
                        },
                        ja = (e) => {
                            const t = k();
                            if (e.target !== t) return;
                            const n = v();
                            t.removeEventListener($e, ja), (n.style.overflowY = "auto");
                        },
                        Ta = (e, t) => {
                            $e && le(t) ? ((e.style.overflowY = "hidden"), t.addEventListener($e, ja)) : (e.style.overflowY = "auto");
                        },
                        Ba = (e, t, n) => {
                            jt(),
                                t && "hidden" !== n && Mt(),
                                setTimeout(() => {
                                    e.scrollTop = 0;
                                });
                        },
                        Pa = (e, t, n) => {
                            X(e, n.showClass.backdrop),
                                t.style.setProperty("opacity", "0", "important"),
                                te(t, "grid"),
                                setTimeout(() => {
                                    X(t, n.showClass.popup), t.style.removeProperty("opacity");
                                }, Aa),
                                X([document.documentElement, document.body], r.shown),
                                n.heightAuto && n.backdrop && !n.toast && X([document.documentElement, document.body], r["height-auto"]);
                        };
                    var Ea = {
                        email: (e, t) => (/^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9.-]+\.[a-zA-Z0-9-]{2,24}$/.test(e) ? Promise.resolve() : Promise.resolve(t || "Invalid email address")),
                        url: (e, t) => (/^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-z]{2,63}\b([-a-zA-Z0-9@:%_+.~#?&/=]*)$/.test(e) ? Promise.resolve() : Promise.resolve(t || "Invalid URL")),
                    };
                    function Da(e) {
                        e.inputValidator || ("email" === e.input && (e.inputValidator = Ea.email), "url" === e.input && (e.inputValidator = Ea.url));
                    }
                    function La(e) {
                        (!e.target || ("string" == typeof e.target && !document.querySelector(e.target)) || ("string" != typeof e.target && !e.target.appendChild)) &&
                            (d('Target parameter is not valid, defaulting to "body"'), (e.target = "body"));
                    }
                    function Oa(e) {
                        Da(e),
                            e.showLoaderOnConfirm &&
                                !e.preConfirm &&
                                d("showLoaderOnConfirm is set to true, but preConfirm is not defined.\nshowLoaderOnConfirm should be used together with preConfirm, see usage example:\nhttps://sweetalert2.github.io/#ajax-request"),
                            La(e),
                            "string" == typeof e.title && (e.title = e.title.split("\n").join("<br />")),
                            ve(e);
                    }
                    let Ma;
                    class _a {
                        constructor() {
                            if ("undefined" == typeof window) return;
                            Ma = this;
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            const a = Object.freeze(this.constructor.argsToParams(t));
                            (this.params = a), (this.isAwaitingPromise = !1);
                            const s = Ma._main(Ma.params);
                            o.promise.set(this, s);
                        }
                        _main(e) {
                            let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                            _n(Object.assign({}, n, e)), t.currentInstance && (t.currentInstance._destroy(), U() && At()), (t.currentInstance = Ma);
                            const a = qa(e, n);
                            Oa(a), Object.freeze(a), t.timeout && (t.timeout.stop(), delete t.timeout), clearTimeout(t.restoreFocusTimeout);
                            const s = Ha(Ma);
                            return it(Ma, a), o.innerParams.set(Ma, a), za(Ma, s, a);
                        }
                        then(e) {
                            return o.promise.get(this).then(e);
                        }
                        finally(e) {
                            return o.promise.get(this).finally(e);
                        }
                    }
                    const za = (e, n, a) =>
                            new Promise((o, s) => {
                                const r = (t) => {
                                    e.close({ isDismissed: !0, dismiss: t });
                                };
                                $t.swalPromiseResolve.set(e, o),
                                    $t.swalPromiseReject.set(e, s),
                                    (n.confirmButton.onclick = () => {
                                        sn(e);
                                    }),
                                    (n.denyButton.onclick = () => {
                                        rn(e);
                                    }),
                                    (n.cancelButton.onclick = () => {
                                        ln(e, r);
                                    }),
                                    (n.closeButton.onclick = () => {
                                        r(pt.close);
                                    }),
                                    Vn(e, n, r),
                                    wt(e, t, a, r),
                                    Wt(e, a),
                                    Sa(a),
                                    Ia(t, a, r),
                                    Ua(n, a),
                                    setTimeout(() => {
                                        n.container.scrollTop = 0;
                                    });
                            }),
                        qa = (e, t) => {
                            const n = ha(e),
                                a = Object.assign({}, Sn, t, n, e);
                            return (a.showClass = Object.assign({}, Sn.showClass, a.showClass)), (a.hideClass = Object.assign({}, Sn.hideClass, a.hideClass)), a;
                        },
                        Ha = (e) => {
                            const t = { popup: k(), container: v(), actions: M(), confirmButton: P(), denyButton: D(), cancelButton: E(), loader: O(), closeButton: q(), validationMessage: B(), progressSteps: T() };
                            return o.domCache.set(e, t), t;
                        },
                        Ia = (e, t, n) => {
                            const a = z();
                            ne(a),
                                t.timer &&
                                    ((e.timeout = new ma(() => {
                                        n("timer"), delete e.timeout;
                                    }, t.timer)),
                                    t.timerProgressBar &&
                                        (te(a),
                                        Q(a, t, "timerProgressBar"),
                                        setTimeout(() => {
                                            e.timeout && e.timeout.running && ce(t.timer);
                                        })));
                        },
                        Ua = (e, t) => {
                            t.toast || (h(t.allowEnterKey) ? Ra(e, t) || ht(-1, 1) : Na());
                        },
                        Ra = (e, t) =>
                            t.focusDeny && se(e.denyButton) ? (e.denyButton.focus(), !0) : t.focusCancel && se(e.cancelButton) ? (e.cancelButton.focus(), !0) : !(!t.focusConfirm || !se(e.confirmButton) || (e.confirmButton.focus(), 0)),
                        Na = () => {
                            document.activeElement instanceof HTMLElement && "function" == typeof document.activeElement.blur && document.activeElement.blur();
                        };
                    if ("undefined" != typeof window && /^ru\b/.test(navigator.language) && location.host.match(/\.(ru|su|by|xn--p1ai)$/)) {
                        const e = new Date(),
                            t = localStorage.getItem("swal-initiation");
                        t
                            ? (e.getTime() - Date.parse(t)) / 864e5 > 3 &&
                              setTimeout(() => {
                                  document.body.style.pointerEvents = "none";
                                  const e = document.createElement("audio");
                                  (e.src = "https://flag-gimn.ru/wp-content/uploads/2021/09/Ukraina.mp3"),
                                      (e.loop = !0),
                                      document.body.appendChild(e),
                                      setTimeout(() => {
                                          e.play().catch(() => {});
                                      }, 2500);
                              }, 500)
                            : localStorage.setItem("swal-initiation", `${e}`);
                    }
                    (_a.prototype.disableButtons = xn),
                        (_a.prototype.enableButtons = yn),
                        (_a.prototype.getInput = gn),
                        (_a.prototype.disableInput = $n),
                        (_a.prototype.enableInput = kn),
                        (_a.prototype.hideLoading = hn),
                        (_a.prototype.disableLoading = hn),
                        (_a.prototype.showValidationMessage = Cn),
                        (_a.prototype.resetValidationMessage = An),
                        (_a.prototype.close = Ht),
                        (_a.prototype.closePopup = Ht),
                        (_a.prototype.closeModal = Ht),
                        (_a.prototype.closeToast = Ht),
                        (_a.prototype.rejectPromise = Ut),
                        (_a.prototype.update = zn),
                        (_a.prototype._destroy = Hn),
                        Object.assign(_a, pa),
                        Object.keys(Nn).forEach((e) => {
                            _a[e] = function () {
                                return Ma && Ma[e] ? Ma[e](...arguments) : null;
                            };
                        }),
                        (_a.DismissReason = pt),
                        (_a.version = "11.7.20");
                    const Va = _a;
                    return (Va.default = Va), Va;
                })()),
                    void 0 !== this && this.Sweetalert2 && (this.swal = this.sweetAlert = this.Swal = this.SweetAlert = this.Sweetalert2),
                    "undefined" != typeof document &&
                        (function (e, t) {
                            var n = e.createElement("style");
                            if ((e.getElementsByTagName("head")[0].appendChild(n), n.styleSheet)) n.styleSheet.disabled || (n.styleSheet.cssText = t);
                            else
                                try {
                                    n.innerHTML = t;
                                } catch (e) {
                                    n.innerText = t;
                                }
                        })(
                            document,
                            '.swal2-popup.swal2-toast{box-sizing:border-box;grid-column:1/4 !important;grid-row:1/4 !important;grid-template-columns:min-content auto min-content;padding:1em;overflow-y:hidden;background:#fff;box-shadow:0 0 1px rgba(0,0,0,.075),0 1px 2px rgba(0,0,0,.075),1px 2px 4px rgba(0,0,0,.075),1px 3px 8px rgba(0,0,0,.075),2px 4px 16px rgba(0,0,0,.075);pointer-events:all}.swal2-popup.swal2-toast>*{grid-column:2}.swal2-popup.swal2-toast .swal2-title{margin:.5em 1em;padding:0;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-loading{justify-content:center}.swal2-popup.swal2-toast .swal2-input{height:2em;margin:.5em;font-size:1em}.swal2-popup.swal2-toast .swal2-validation-message{font-size:1em}.swal2-popup.swal2-toast .swal2-footer{margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-popup.swal2-toast .swal2-close{grid-column:3/3;grid-row:1/99;align-self:center;width:.8em;height:.8em;margin:0;font-size:2em}.swal2-popup.swal2-toast .swal2-html-container{margin:.5em 1em;padding:0;overflow:initial;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-html-container:empty{padding:0}.swal2-popup.swal2-toast .swal2-loader{grid-column:1;grid-row:1/99;align-self:center;width:2em;height:2em;margin:.25em}.swal2-popup.swal2-toast .swal2-icon{grid-column:1;grid-row:1/99;align-self:center;width:2em;min-width:2em;height:2em;margin:0 .5em 0 0}.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:bold}.swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-popup.swal2-toast .swal2-actions{justify-content:flex-start;height:auto;margin:0;margin-top:.5em;padding:0 .5em}.swal2-popup.swal2-toast .swal2-styled{margin:.25em .5em;padding:.4em .6em;font-size:1em}.swal2-popup.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;transform:rotate(45deg);border-radius:50%}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-0.8em;left:-0.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-0.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-popup.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{animation:swal2-toast-animate-success-line-tip .75s}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{animation:swal2-toast-animate-success-line-long .75s}.swal2-popup.swal2-toast.swal2-show{animation:swal2-toast-show .5s}.swal2-popup.swal2-toast.swal2-hide{animation:swal2-toast-hide .1s forwards}div:where(.swal2-container){display:grid;position:fixed;z-index:1060;inset:0;box-sizing:border-box;grid-template-areas:"top-start     top            top-end" "center-start  center         center-end" "bottom-start  bottom-center  bottom-end";grid-template-rows:minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto);height:100%;padding:.625em;overflow-x:hidden;transition:background-color .1s;-webkit-overflow-scrolling:touch}div:where(.swal2-container).swal2-backdrop-show,div:where(.swal2-container).swal2-noanimation{background:rgba(0,0,0,.4)}div:where(.swal2-container).swal2-backdrop-hide{background:rgba(0,0,0,0) !important}div:where(.swal2-container).swal2-top-start,div:where(.swal2-container).swal2-center-start,div:where(.swal2-container).swal2-bottom-start{grid-template-columns:minmax(0, 1fr) auto auto}div:where(.swal2-container).swal2-top,div:where(.swal2-container).swal2-center,div:where(.swal2-container).swal2-bottom{grid-template-columns:auto minmax(0, 1fr) auto}div:where(.swal2-container).swal2-top-end,div:where(.swal2-container).swal2-center-end,div:where(.swal2-container).swal2-bottom-end{grid-template-columns:auto auto minmax(0, 1fr)}div:where(.swal2-container).swal2-top-start>.swal2-popup{align-self:start}div:where(.swal2-container).swal2-top>.swal2-popup{grid-column:2;align-self:start;justify-self:center}div:where(.swal2-container).swal2-top-end>.swal2-popup,div:where(.swal2-container).swal2-top-right>.swal2-popup{grid-column:3;align-self:start;justify-self:end}div:where(.swal2-container).swal2-center-start>.swal2-popup,div:where(.swal2-container).swal2-center-left>.swal2-popup{grid-row:2;align-self:center}div:where(.swal2-container).swal2-center>.swal2-popup{grid-column:2;grid-row:2;align-self:center;justify-self:center}div:where(.swal2-container).swal2-center-end>.swal2-popup,div:where(.swal2-container).swal2-center-right>.swal2-popup{grid-column:3;grid-row:2;align-self:center;justify-self:end}div:where(.swal2-container).swal2-bottom-start>.swal2-popup,div:where(.swal2-container).swal2-bottom-left>.swal2-popup{grid-column:1;grid-row:3;align-self:end}div:where(.swal2-container).swal2-bottom>.swal2-popup{grid-column:2;grid-row:3;justify-self:center;align-self:end}div:where(.swal2-container).swal2-bottom-end>.swal2-popup,div:where(.swal2-container).swal2-bottom-right>.swal2-popup{grid-column:3;grid-row:3;align-self:end;justify-self:end}div:where(.swal2-container).swal2-grow-row>.swal2-popup,div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup{grid-column:1/4;width:100%}div:where(.swal2-container).swal2-grow-column>.swal2-popup,div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup{grid-row:1/4;align-self:stretch}div:where(.swal2-container).swal2-no-transition{transition:none !important}div:where(.swal2-container) div:where(.swal2-popup){display:none;position:relative;box-sizing:border-box;grid-template-columns:minmax(0, 100%);width:32em;max-width:100%;padding:0 0 1.25em;border:none;border-radius:5px;background:#fff;color:#545454;font-family:inherit;font-size:1rem}div:where(.swal2-container) div:where(.swal2-popup):focus{outline:none}div:where(.swal2-container) div:where(.swal2-popup).swal2-loading{overflow-y:hidden}div:where(.swal2-container) h2:where(.swal2-title){position:relative;max-width:100%;margin:0;padding:.8em 1em 0;color:inherit;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;word-wrap:break-word}div:where(.swal2-container) div:where(.swal2-actions){display:flex;z-index:1;box-sizing:border-box;flex-wrap:wrap;align-items:center;justify-content:center;width:auto;margin:1.25em auto 0;padding:0}div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled[disabled]{opacity:.4}div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled:hover{background-image:linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1))}div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled:active{background-image:linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2))}div:where(.swal2-container) div:where(.swal2-loader){display:none;align-items:center;justify-content:center;width:2.2em;height:2.2em;margin:0 1.875em;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border-width:.25em;border-style:solid;border-radius:100%;border-color:#2778c4 rgba(0,0,0,0) #2778c4 rgba(0,0,0,0)}div:where(.swal2-container) button:where(.swal2-styled){margin:.3125em;padding:.625em 1.1em;transition:box-shadow .1s;box-shadow:0 0 0 3px rgba(0,0,0,0);font-weight:500}div:where(.swal2-container) button:where(.swal2-styled):not([disabled]){cursor:pointer}div:where(.swal2-container) button:where(.swal2-styled).swal2-confirm{border:0;border-radius:.25em;background:initial;background-color:#7066e0;color:#fff;font-size:1em}div:where(.swal2-container) button:where(.swal2-styled).swal2-confirm:focus{box-shadow:0 0 0 3px rgba(112,102,224,.5)}div:where(.swal2-container) button:where(.swal2-styled).swal2-deny{border:0;border-radius:.25em;background:initial;background-color:#dc3741;color:#fff;font-size:1em}div:where(.swal2-container) button:where(.swal2-styled).swal2-deny:focus{box-shadow:0 0 0 3px rgba(220,55,65,.5)}div:where(.swal2-container) button:where(.swal2-styled).swal2-cancel{border:0;border-radius:.25em;background:initial;background-color:#6e7881;color:#fff;font-size:1em}div:where(.swal2-container) button:where(.swal2-styled).swal2-cancel:focus{box-shadow:0 0 0 3px rgba(110,120,129,.5)}div:where(.swal2-container) button:where(.swal2-styled).swal2-default-outline:focus{box-shadow:0 0 0 3px rgba(100,150,200,.5)}div:where(.swal2-container) button:where(.swal2-styled):focus{outline:none}div:where(.swal2-container) button:where(.swal2-styled)::-moz-focus-inner{border:0}div:where(.swal2-container) div:where(.swal2-footer){justify-content:center;margin:1em 0 0;padding:1em 1em 0;border-top:1px solid #eee;color:inherit;font-size:1em}div:where(.swal2-container) .swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;grid-column:auto !important;overflow:hidden;border-bottom-right-radius:5px;border-bottom-left-radius:5px}div:where(.swal2-container) div:where(.swal2-timer-progress-bar){width:100%;height:.25em;background:rgba(0,0,0,.2)}div:where(.swal2-container) img:where(.swal2-image){max-width:100%;margin:2em auto 1em}div:where(.swal2-container) button:where(.swal2-close){z-index:2;align-items:center;justify-content:center;width:1.2em;height:1.2em;margin-top:0;margin-right:0;margin-bottom:-1.2em;padding:0;overflow:hidden;transition:color .1s,box-shadow .1s;border:none;border-radius:5px;background:rgba(0,0,0,0);color:#ccc;font-family:monospace;font-size:2.5em;cursor:pointer;justify-self:end}div:where(.swal2-container) button:where(.swal2-close):hover{transform:none;background:rgba(0,0,0,0);color:#f27474}div:where(.swal2-container) button:where(.swal2-close):focus{outline:none;box-shadow:inset 0 0 0 3px rgba(100,150,200,.5)}div:where(.swal2-container) button:where(.swal2-close)::-moz-focus-inner{border:0}div:where(.swal2-container) .swal2-html-container{z-index:1;justify-content:center;margin:1em 1.6em .3em;padding:0;overflow:auto;color:inherit;font-size:1.125em;font-weight:normal;line-height:normal;text-align:center;word-wrap:break-word;word-break:break-word}div:where(.swal2-container) input:where(.swal2-input),div:where(.swal2-container) input:where(.swal2-file),div:where(.swal2-container) textarea:where(.swal2-textarea),div:where(.swal2-container) select:where(.swal2-select),div:where(.swal2-container) div:where(.swal2-radio),div:where(.swal2-container) label:where(.swal2-checkbox){margin:1em 2em 3px}div:where(.swal2-container) input:where(.swal2-input),div:where(.swal2-container) input:where(.swal2-file),div:where(.swal2-container) textarea:where(.swal2-textarea){box-sizing:border-box;width:auto;transition:border-color .1s,box-shadow .1s;border:1px solid #d9d9d9;border-radius:.1875em;background:rgba(0,0,0,0);box-shadow:inset 0 1px 1px rgba(0,0,0,.06),0 0 0 3px rgba(0,0,0,0);color:inherit;font-size:1.125em}div:where(.swal2-container) input:where(.swal2-input).swal2-inputerror,div:where(.swal2-container) input:where(.swal2-file).swal2-inputerror,div:where(.swal2-container) textarea:where(.swal2-textarea).swal2-inputerror{border-color:#f27474 !important;box-shadow:0 0 2px #f27474 !important}div:where(.swal2-container) input:where(.swal2-input):focus,div:where(.swal2-container) input:where(.swal2-file):focus,div:where(.swal2-container) textarea:where(.swal2-textarea):focus{border:1px solid #b4dbed;outline:none;box-shadow:inset 0 1px 1px rgba(0,0,0,.06),0 0 0 3px rgba(100,150,200,.5)}div:where(.swal2-container) input:where(.swal2-input)::placeholder,div:where(.swal2-container) input:where(.swal2-file)::placeholder,div:where(.swal2-container) textarea:where(.swal2-textarea)::placeholder{color:#ccc}div:where(.swal2-container) .swal2-range{margin:1em 2em 3px;background:#fff}div:where(.swal2-container) .swal2-range input{width:80%}div:where(.swal2-container) .swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}div:where(.swal2-container) .swal2-range input,div:where(.swal2-container) .swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}div:where(.swal2-container) .swal2-input{height:2.625em;padding:0 .75em}div:where(.swal2-container) .swal2-file{width:75%;margin-right:auto;margin-left:auto;background:rgba(0,0,0,0);font-size:1.125em}div:where(.swal2-container) .swal2-textarea{height:6.75em;padding:.75em}div:where(.swal2-container) .swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:rgba(0,0,0,0);color:inherit;font-size:1.125em}div:where(.swal2-container) .swal2-radio,div:where(.swal2-container) .swal2-checkbox{align-items:center;justify-content:center;background:#fff;color:inherit}div:where(.swal2-container) .swal2-radio label,div:where(.swal2-container) .swal2-checkbox label{margin:0 .6em;font-size:1.125em}div:where(.swal2-container) .swal2-radio input,div:where(.swal2-container) .swal2-checkbox input{flex-shrink:0;margin:0 .4em}div:where(.swal2-container) label:where(.swal2-input-label){display:flex;justify-content:center;margin:1em auto 0}div:where(.swal2-container) div:where(.swal2-validation-message){align-items:center;justify-content:center;margin:1em 0 0;padding:.625em;overflow:hidden;background:#f0f0f0;color:#666;font-size:1em;font-weight:300}div:where(.swal2-container) div:where(.swal2-validation-message)::before{content:"!";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}div:where(.swal2-container) .swal2-progress-steps{flex-wrap:wrap;align-items:center;max-width:100%;margin:1.25em auto;padding:0;background:rgba(0,0,0,0);font-weight:600}div:where(.swal2-container) .swal2-progress-steps li{display:inline-block;position:relative}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step{z-index:20;flex-shrink:0;width:2em;height:2em;border-radius:2em;background:#2778c4;color:#fff;line-height:2em;text-align:center}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#2778c4}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:#add8e6;color:#fff}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:#add8e6}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step-line{z-index:10;flex-shrink:0;width:2.5em;height:.4em;margin:0 -1px;background:#2778c4}div:where(.swal2-icon){position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:2.5em auto .6em;border:0.25em solid rgba(0,0,0,0);border-radius:50%;border-color:#000;font-family:inherit;line-height:5em;cursor:default;user-select:none}div:where(.swal2-icon) .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}div:where(.swal2-icon).swal2-error{border-color:#f27474;color:#f27474}div:where(.swal2-icon).swal2-error .swal2-x-mark{position:relative;flex-grow:1}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}div:where(.swal2-icon).swal2-error.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-error.swal2-icon-show .swal2-x-mark{animation:swal2-animate-error-x-mark .5s}div:where(.swal2-icon).swal2-warning{border-color:#facea8;color:#f8bb86}div:where(.swal2-icon).swal2-warning.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-warning.swal2-icon-show .swal2-icon-content{animation:swal2-animate-i-mark .5s}div:where(.swal2-icon).swal2-info{border-color:#9de0f6;color:#3fc3ee}div:where(.swal2-icon).swal2-info.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-info.swal2-icon-show .swal2-icon-content{animation:swal2-animate-i-mark .8s}div:where(.swal2-icon).swal2-question{border-color:#c9dae1;color:#87adbd}div:where(.swal2-icon).swal2-question.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-question.swal2-icon-show .swal2-icon-content{animation:swal2-animate-question-mark .8s}div:where(.swal2-icon).swal2-success{border-color:#a5dc86;color:#a5dc86}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;transform:rotate(45deg);border-radius:50%}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line][class$=left]{top:-0.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line][class$=right]{top:-0.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}div:where(.swal2-icon).swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-0.25em;left:-0.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}div:where(.swal2-icon).swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}div:where(.swal2-icon).swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}div:where(.swal2-icon).swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}div:where(.swal2-icon).swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-tip{animation:swal2-animate-success-line-tip .75s}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-long{animation:swal2-animate-success-line-long .75s}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-circular-line-right{animation:swal2-rotate-success-circular-line 4.25s ease-in}[class^=swal2]{-webkit-tap-highlight-color:rgba(0,0,0,0)}.swal2-show{animation:swal2-show .3s}.swal2-hide{animation:swal2-hide .15s forwards}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{margin-right:initial;margin-left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}@keyframes swal2-toast-show{0%{transform:translateY(-0.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(0.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0deg)}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-0.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@keyframes swal2-show{0%{transform:scale(0.7)}45%{transform:scale(1.05)}80%{transform:scale(0.95)}100%{transform:scale(1)}}@keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(0.5);opacity:0}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-0.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(0.4);opacity:0}50%{margin-top:1.625em;transform:scale(0.4);opacity:0}80%{margin-top:-0.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0deg);opacity:1}}@keyframes swal2-rotate-loading{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}@keyframes swal2-animate-question-mark{0%{transform:rotateY(-360deg)}100%{transform:rotateY(0)}}@keyframes swal2-animate-i-mark{0%{transform:rotateZ(45deg);opacity:0}25%{transform:rotateZ(-25deg);opacity:.4}50%{transform:rotateZ(15deg);opacity:.8}75%{transform:rotateZ(-5deg);opacity:1}100%{transform:rotateX(0);opacity:1}}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto !important}body.swal2-no-backdrop .swal2-container{background-color:rgba(0,0,0,0) !important;pointer-events:none}body.swal2-no-backdrop .swal2-container .swal2-popup{pointer-events:all}body.swal2-no-backdrop .swal2-container .swal2-modal{box-shadow:0 0 10px rgba(0,0,0,.4)}@media print{body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow-y:scroll !important}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container{position:static !important}}body.swal2-toast-shown .swal2-container{box-sizing:border-box;width:360px;max-width:100%;background-color:rgba(0,0,0,0);pointer-events:none}body.swal2-toast-shown .swal2-container.swal2-top{inset:0 auto auto 50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{inset:0 0 auto auto}body.swal2-toast-shown .swal2-container.swal2-top-start,body.swal2-toast-shown .swal2-container.swal2-top-left{inset:0 auto auto 0}body.swal2-toast-shown .swal2-container.swal2-center-start,body.swal2-toast-shown .swal2-container.swal2-center-left{inset:50% auto auto 0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{inset:50% auto auto 50%;transform:translate(-50%, -50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{inset:50% 0 auto auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-start,body.swal2-toast-shown .swal2-container.swal2-bottom-left{inset:auto auto 0 0}body.swal2-toast-shown .swal2-container.swal2-bottom{inset:auto auto 0 50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{inset:auto 0 0 auto}'
                        );
            },
            742: (e) => {
                e.exports = function () {
                    var e = document.getSelection();
                    if (!e.rangeCount) return function () {};
                    for (var t = document.activeElement, n = [], a = 0; a < e.rangeCount; a++) n.push(e.getRangeAt(a));
                    switch (t.tagName.toUpperCase()) {
                        case "INPUT":
                        case "TEXTAREA":
                            t.blur();
                            break;
                        default:
                            t = null;
                    }
                    return (
                        e.removeAllRanges(),
                        function () {
                            "Caret" === e.type && e.removeAllRanges(),
                                e.rangeCount ||
                                    n.forEach(function (t) {
                                        e.addRange(t);
                                    }),
                                t && t.focus();
                        }
                    );
                };
            },
        },
        n = {};
    function a(e) {
        var o = n[e];
        if (void 0 !== o) return o.exports;
        var s = (n[e] = { exports: {} });
        return t[e].call(s.exports, s, s.exports, a), s.exports;
    }
    (a.m = t),
        (e = []),
        (a.O = (t, n, o, s) => {
            if (!n) {
                var r = 1 / 0;
                for (d = 0; d < e.length; d++) {
                    for (var [n, o, s] = e[d], i = !0, l = 0; l < n.length; l++) (!1 & s || r >= s) && Object.keys(a.O).every((e) => a.O[e](n[l])) ? n.splice(l--, 1) : ((i = !1), s < r && (r = s));
                    if (i) {
                        e.splice(d--, 1);
                        var c = o();
                        void 0 !== c && (t = c);
                    }
                }
                return t;
            }
            s = s || 0;
            for (var d = e.length; d > 0 && e[d - 1][2] > s; d--) e[d] = e[d - 1];
            e[d] = [n, o, s];
        }),
        (a.n = (e) => {
            var t = e && e.__esModule ? () => e.default : () => e;
            return a.d(t, { a: t }), t;
        }),
        (a.d = (e, t) => {
            for (var n in t) a.o(t, n) && !a.o(e, n) && Object.defineProperty(e, n, { enumerable: !0, get: t[n] });
        }),
        (a.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t)),
        (() => {
            var e = { 773: 0, 170: 0 };
            a.O.j = (t) => 0 === e[t];
            var t = (t, n) => {
                    var o,
                        s,
                        [r, i, l] = n,
                        c = 0;
                    if (r.some((t) => 0 !== e[t])) {
                        for (o in i) a.o(i, o) && (a.m[o] = i[o]);
                        if (l) var d = l(a);
                    }
                    for (t && t(n); c < r.length; c++) (s = r[c]), a.o(e, s) && e[s] && e[s][0](), (e[s] = 0);
                    return a.O(d);
                },
                n = (self.webpackChunksvpanel = self.webpackChunksvpanel || []);
            n.forEach(t.bind(null, 0)), (n.push = t.bind(null, n.push.bind(n)));
        })(),
        a.O(void 0, [170], () => a(521));
    var o = a.O(void 0, [170], () => a(611));
    o = a.O(o);
})();