<?php

/**
 * By SoVPN
 * Github: https://github.com/SoVPN
 */

define('PATH', __DIR__);


require_once 'vendor/autoload.php';
require_once 'bootstrap/bootstrap.php';
