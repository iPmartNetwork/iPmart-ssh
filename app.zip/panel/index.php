<?php

/**
 * By ali hassanzadeh
 * Github: https://github.com/ipmartnetwork
 */

define('PATH', __DIR__);


require_once 'vendor/autoload.php';
require_once 'bootstrap/bootstrap.php';
