<?php
/**
 * By SoVPN
 * Github: https://github.com/SoVPN
 */

if (!defined('PATH')) die();

if (getConfig('session', 'enabled')) {
  $container['session'] = function ($c) {
    return new \SlimSession\Helper;
  };
}
