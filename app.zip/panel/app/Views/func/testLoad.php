<?php

echo '<h2 style="text-align:center;color:yellow;">123There is no error uploading files!</h1>';

?>