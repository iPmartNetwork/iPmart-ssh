<div id="banner">	
	<div class="bannerc">
		<script>
		function ifyAjax(){
			// Progress Bar CPU
			var cpuAvg  = "<?= $cpuData['loadAvg'] ?>%"
			var cpuData = "<?= $cpuNum = 100 - (($cpuData['loadAvg'] * 1.9) - 100) ?>"
			$('#cpuAvg').text(cpuAvg);
			$('#cpuGroup').find('#cpuLine').animate({
				'stroke-dashoffset': cpuData
			}, 500)
		}
		
		
		
		
		
		
		
//		setInterval(function() {
//			$(".cpuAvg").load(window.location + " .cpuAvg");
//			$("#cpuGroup").load(window.location + " #cpuLine");
//			$(".cpuAvg").load(location.href + " .cpuAvg");
//			$("#cpuGroup").load(location.href + " #cpuLine");
//		}, 2000);
		</script>
	</div>
</div>