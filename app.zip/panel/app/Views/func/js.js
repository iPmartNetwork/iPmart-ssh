phpVars["value1"];
phpVars["value2"];