<?php
/**
 * Crate some fake data to update the progress bar
 */
$cpuAvg = $cpuData['loadAvg'];
//$result = array("SLA" => $cpuAvg);
$result = array($cpuAvg => rand(1,100));
$json = json_encode($result); 
echo $json;

