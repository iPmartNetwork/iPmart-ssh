<div class="naviMenu">
      <a href="<?= baseUrl("settings") ?>" class="naviIcon"><i class="fa fa-gear naviIcon"></i></a>
	<label for="btnAddUser"><i class="fa fa-user-plus naviIcon"></i></label>
	<i class="fa fa-users naviIcon btnOnline loginPanel-close"></i>
	<i class="fa fa-bell naviIcon"></i>
</div>

<div class="modal fade" id="ajax-modal-view" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" tabindex="-1">
	<div id="modal-loading-body" style="display: none;">
		<div class="modal-dialog modal-xs">
			<div class="modal-content">
				<div class="modal-body">
					<div class="text-center">
						<div class="spinner-border " role="status"></div>
						<p class="d-block mt-2">در حال بارگذاری...</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>
<script src="<?= assets("js/bootstrap.bundle.min.js") ?>"></script>
<script src="<?= $mainAppEnqueue["js_url"] ?>"></script>
<script>
$(document).ready(function(){	
	// SideBar
	if(window.location.pathname == '/dashboard'){
		$('#toggle-pc').addClass('active-btn');
	}
	if(window.location.pathname == '/settings'){
		$('.side-btn-f').addClass('active-btn');
	}
	if(window.location.pathname == '/users'){
		$('body').addClass('usersPage');
	}
	if(window.location.pathname == '/users/online'){
		$('body').addClass('usersOnline');
	}
	
	// Mobile Navigation Menu
	$('#btnContent').on('click', function() {
		$('.content').toggleClass('navi-close');
		$('#btnContent').toggleClass('btn-open');
	});
	$('.naviCover').on('click', function() {
		$('.content').addClass('navi-close');
		$('.panelUserOnline').addClass('loginPanel-close');
		$('#btnContent').addClass('btn-open');
	});
	$('.btnOnline').on('click', function() {
		$('.panelUserOnline').toggleClass('loginPanel-close');
	});
});
</script>
<?php footerFiles(); ?>
</html>