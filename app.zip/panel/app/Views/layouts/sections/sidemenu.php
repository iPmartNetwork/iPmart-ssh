<div id="sidebarnav" class="sidebarnav close">
	<div class="sidebarup">
		<div class="image-text">
			<span class="image">
				<img src="<?= assets("images/logo.svg") ?>" width="70" class="mb-2" />
			</span>
			<div class="text logo-text">
				<span class="name">iPmart SSH</span>
				<span class="profession">Web developer</span>
			</div>
			<div class="user-sidebar-counter">
				<div id="sidCounter">
					<span class="sidebar-counter-num sidCounter" style="background:var(<?= userOnlineToggle() ?>)!important;"><?= userOnlineCounter() ?></span>
				</div>
				<span class="sidebar-counter-text">Online</span>
			</div>
		</div>
	</div>
	<div class="menu-bar">

	</div>
	<div class="bottom-content">
		<ul class="nav flex-column mb-auto menu">
			<li>
				<span id="toggle-pc"><i class="fa fa-earth-americas icon bx bx-chevron-right toggle menu-icon icon"></i>
					<span id="toggle-mobile"><i class="fa fa-earth-americas icon bx bx-chevron-right toggle menu-icon icon"></i></span>
				</span>
			</li>
			<li class="nav-item">
				<a href="<?= baseUrl("dashboard") ?>" class="nav-link <?= $activeMenu == "dashboard" ? "active" : "link-body-emphasis" ?>">
					<i class="fa fa-dashboard icon menu-icon"></i>
				</a>
			</li>
			<li>
			<?php if ($userRole == "admin") { ?>
				<a href="<?= baseUrl("admins") ?>" class="nav-link <?= $activeMenu == "admins" ? "active" : "link-body-emphasis" ?>">
					<i class="fa fa-users-gear icon menu-icon"></i>
				</a>
			</li>
			<li>
				<a href="<?= baseUrl("settings") ?>" class="nav-link <?= $activeMenu == "settings" ? "active" : "link-body-emphasis" ?>">
					<i class="fa fa-gear icon menu-icon"></i>
				</a>
			<?php } ?>
			</li>
			<li>
				<a href="<?= baseUrl("pages/filtering") ?>" class="nav-link <?= $activeMenu == "filtering" ? "active" : "link-body-emphasis" ?> ">
					<?= inlineIcon("shield-halved", "menu-icon") ?>
                </a>
			</li>
			
			<li>
		</ul>
		<div class="bottom-content-down">
			<a href="<?= baseUrl("logout") ?>" class="nav-link-power-off">
				<i class="fa fa-power-off icon menu-icon"></i>
			</a>
			<div class="toggle-switch">
				<button type="button" id="btn-toggle-theme" class="btn btn-toggle-theme btn-sm switch" data-theme="<?= $activeTheme ?>" aria-pressed="false">
					<?= inlineIcon($activeTheme == "dark") ?>
					<span class=""></span>
				</button>
				<span class="text-body-sidebar">
				iPmart SSH
				</span>
			</div>
		</div>
	</div>
</div>
<div class=" switch-overlay"></div>