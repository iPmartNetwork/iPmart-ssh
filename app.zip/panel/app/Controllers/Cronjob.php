<?php

/**
 * By SoVPN
 * Github: https://github.com/SoVPN
 */

namespace App\Controllers;


class Cronjob extends BaseController
{

    public function master($request, $response, $arg)
    {
        $cModel = new \App\Models\Cronjob();
        $cModel->init();

    }
}
