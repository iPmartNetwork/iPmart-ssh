<?php
/**
 * By SoVPN
 * Github: https://github.com/SoVPN
 */

if (!defined('PATH')) die();

/**
 * Uploads Config
 */
$configs['upload']['dir'] = PATH_ASSETS . DS . 'uploads';
$configs['upload']['temp'] = PATH_TEMP;
$configs['upload']['url'] = $configs['url'] . 'assets/uploads/';

?>
